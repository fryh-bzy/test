#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rbd_deleted_volume_cleaner.py

定时扫描指定 Ceph RBD pool,处理 Cinder 遗留的 "*.deleted" 卷:

    1. 找到所有以 .deleted 结尾的镜像(这些是 Cinder 因为存在
       COW clone 依赖而无法直接删除、转而重命名保留的卷)
    2. 遍历该镜像的所有快照
    3. 对每个快照检查是否还有 children(即是否还有其他卷是基于
       这个快照 clone 出来的)
    4. 如果没有 children:
         - 如果快照是 protected 状态,先 unprotect
         - 删除该快照
    5. 当这个 .deleted 卷的所有快照都被清理干净后,删除这个卷本身

依赖:
    需要节点上安装了 ceph 的 python 绑定,通常随 ceph-common 包提供:
        Debian/Ubuntu: apt install python3-rados python3-rbd
        RHEL/CentOS:   yum install python3-rados python3-rbd
    或者集群有提供 pip 包的情况下: pip install rados rbd

用法示例:
    # 单次检查一遍,不做任何删除,只打印会做什么(强烈建议先跑这个)
    python3 rbd_deleted_volume_cleaner.py --pool volumes --dry-run --once

    # 每 300 秒扫描一次,真正执行清理
    python3 rbd_deleted_volume_cleaner.py --pool volumes --interval 300

    # 指定 ceph 配置文件和用户
    python3 rbd_deleted_volume_cleaner.py \
        --pool volumes \
        --conf /etc/ceph/ceph.conf \
        --client-name client.cinder \
        --interval 300
"""

import argparse
import logging
import signal
import sys
import time

try:
    import rados
    import rbd
except ImportError:
    print(
        "错误: 未找到 rados/rbd python 绑定。\n"
        "请先安装: apt install python3-rados python3-rbd "
        "(或对应发行版的等效包)",
        file=sys.stderr,
    )
    sys.exit(1)


LOG = logging.getLogger("rbd_deleted_volume_cleaner")

# 是否收到退出信号,收到后当前这一轮扫描结束后就优雅退出
_SHOULD_STOP = False


def _handle_signal(signum, frame):
    global _SHOULD_STOP
    LOG.info("收到信号 %s, 将在本轮扫描结束后退出", signum)
    _SHOULD_STOP = True


class RBDClient(object):
    """封装 rados/rbd 的连接管理,支持 with 语句"""

    def __init__(self, conf, client_name, pool):
        self.conf = conf
        self.client_name = client_name
        self.pool = pool
        self.cluster = None
        self.ioctx = None

    def __enter__(self):
        self.cluster = rados.Rados(
            conffile=self.conf, name=self.client_name
        )
        self.cluster.connect()
        self.ioctx = self.cluster.open_ioctx(self.pool)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.ioctx is not None:
            self.ioctx.close()
        if self.cluster is not None:
            self.cluster.shutdown()


def get_children_info(image, snap_name):
    """给定一个已打开的 rbd.Image 对象和快照名,返回依赖该快照的
    (pool, image_name) 列表。

    注意: list_children() 依赖于 image 当前的 snapshot 上下文,
    所以必须先 set_snap(snap_name),用完记得 set_snap(None) 复位,
    否则会影响后续对这个 image 对象的其他操作。
    """
    image.set_snap(snap_name)
    try:
        children = image.list_children()
    finally:
        image.set_snap(None)
    return children


def cleanup_one_deleted_volume(rbd_inst, ioctx, image_name, dry_run):
    """处理单个 .deleted 卷:清理无依赖的快照,若卷本身也无快照残留
    则一并删除卷本身。

    返回 True 表示这个卷已经被(或应当被)彻底删除,
    返回 False 表示这个卷还有未清理完的依赖,留到下一轮再处理。
    """
    try:
        image = rbd.Image(ioctx, image_name)
    except rbd.ImageNotFound:
        LOG.debug("镜像 %s 已不存在,跳过", image_name)
        return True

    try:
        try:
            snaps = list(image.list_snaps())
        except Exception:
            LOG.exception("列出 %s 的快照失败,跳过本轮", image_name)
            return False

        remaining_snaps = 0

        for snap in snaps:
            snap_name = snap["name"]
            try:
                children = get_children_info(image, snap_name)
            except Exception:
                LOG.exception(
                    "检查快照 %s@%s 的 children 失败,跳过该快照",
                    image_name, snap_name,
                )
                remaining_snaps += 1
                continue

            if children:
                LOG.info(
                    "快照 %s@%s 仍被 %d 个卷依赖,暂不清理: %s",
                    image_name, snap_name, len(children), children,
                )
                remaining_snaps += 1
                continue

            # 没有 children 了,可以清理这个快照
            is_protected = False
            try:
                is_protected = image.is_protected_snap(snap_name)
            except Exception:
                LOG.exception(
                    "检查快照 %s@%s 是否 protected 失败", image_name, snap_name
                )

            if dry_run:
                LOG.info(
                    "[DRY-RUN] 将 unprotect(如需要) 并删除快照 %s@%s "
                    "(protected=%s)",
                    image_name, snap_name, is_protected,
                )
                continue

            try:
                if is_protected:
                    LOG.info("unprotect 快照 %s@%s", image_name, snap_name)
                    image.unprotect_snap(snap_name)
            except rbd.InvalidArgument:
                LOG.info(
                    "%s@%s 已经不是 protected 状态,跳过 unprotect",
                    image_name, snap_name,
                )
            except rbd.ImageBusy:
                LOG.warning(
                    "unprotect %s@%s 时提示 ImageBusy,可能刚有新 clone 出现,"
                    "本轮跳过该快照",
                    image_name, snap_name,
                )
                remaining_snaps += 1
                continue
            except Exception:
                LOG.exception(
                    "unprotect 快照 %s@%s 失败,跳过该快照",
                    image_name, snap_name,
                )
                remaining_snaps += 1
                continue

            try:
                LOG.info("删除快照 %s@%s", image_name, snap_name)
                image.remove_snap(snap_name)
            except rbd.ImageNotFound:
                LOG.info("快照 %s@%s 已不存在", image_name, snap_name)
            except rbd.ImageBusy:
                LOG.warning(
                    "删除快照 %s@%s 时提示 ImageBusy,本轮跳过",
                    image_name, snap_name,
                )
                remaining_snaps += 1
            except Exception:
                LOG.exception(
                    "删除快照 %s@%s 失败", image_name, snap_name
                )
                remaining_snaps += 1

        return remaining_snaps == 0

    finally:
        image.close()


def try_remove_volume(rbd_inst, ioctx, image_name, dry_run):
    """在确认没有快照残留之后,真正删除 .deleted 卷本身"""
    if dry_run:
        LOG.info("[DRY-RUN] 将删除卷 %s", image_name)
        return

    try:
        LOG.info("删除卷 %s", image_name)
        rbd_inst.remove(ioctx, image_name)
    except rbd.ImageNotFound:
        LOG.info("卷 %s 已不存在", image_name)
    except rbd.ImageBusy:
        LOG.warning("卷 %s 仍处于 busy 状态(可能仍被挂载或有其他引用),跳过", image_name)
    except rbd.ImageHasSnapshots:
        LOG.warning("卷 %s 仍有快照残留,跳过(下一轮再检查)", image_name)
    except Exception:
        LOG.exception("删除卷 %s 失败", image_name)


def run_once(conf, client_name, pool, suffix, dry_run):
    """执行一轮完整扫描"""
    LOG.info("开始扫描 pool=%s 中的 %s 卷 (dry_run=%s)", pool, suffix, dry_run)

    with RBDClient(conf, client_name, pool) as client:
        rbd_inst = rbd.RBD()
        try:
            all_images = rbd_inst.list(client.ioctx)
        except Exception:
            LOG.exception("列出 pool %s 中的镜像失败", pool)
            return

        target_images = [n for n in all_images if n.endswith(suffix)]
        LOG.info("本轮发现 %d 个待检查的卷", len(target_images))

        cleaned = 0
        for image_name in target_images:
            no_snaps_left = cleanup_one_deleted_volume(
                rbd_inst, client.ioctx, image_name, dry_run
            )
            if no_snaps_left:
                try_remove_volume(rbd_inst, client.ioctx, image_name, dry_run)
                cleaned += 1

        LOG.info("本轮扫描结束,%d/%d 个卷已清理或达到可删除条件",
                  cleaned, len(target_images))


def main():
    parser = argparse.ArgumentParser(
        description="定时清理 Ceph RBD pool 中 Cinder 遗留的 .deleted 卷"
    )
    parser.add_argument("--pool", required=True, help="RBD pool 名称,如 volumes")
    parser.add_argument(
        "--conf", default="/etc/ceph/ceph.conf", help="ceph 配置文件路径"
    )
    parser.add_argument(
        "--client-name",
        default="client.admin",
        help="连接 ceph 用的客户端名,如 client.cinder",
    )
    parser.add_argument(
        "--suffix", default=".deleted", help="待清理卷的名称后缀,默认 .deleted"
    )
    parser.add_argument(
        "--interval", type=int, default=300, help="扫描间隔秒数,默认 300"
    )
    parser.add_argument(
        "--once", action="store_true", help="只扫描一轮就退出,不进入循环"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只打印会执行的操作,不实际 unprotect/删除任何东西",
    )
    parser.add_argument(
        "--log-file", default=None, help="日志输出文件,不指定则输出到 stdout"
    )
    parser.add_argument(
        "--verbose", action="store_true", help="输出 DEBUG 级别日志"
    )
    args = parser.parse_args()

    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        filename=args.log_file,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    if args.dry_run:
        LOG.warning("当前处于 DRY-RUN 模式,不会执行任何实际删除操作")

    if args.once:
        run_once(args.conf, args.client_name, args.pool, args.suffix, args.dry_run)
        return

    LOG.info("进入循环模式,扫描间隔 %d 秒,Ctrl+C 可安全退出", args.interval)
    while not _SHOULD_STOP:
        try:
            run_once(
                args.conf, args.client_name, args.pool, args.suffix, args.dry_run
            )
        except Exception:
            LOG.exception("本轮扫描出现未捕获异常,等待下一轮重试")

        for _ in range(args.interval):
            if _SHOULD_STOP:
                break
            time.sleep(1)

    LOG.info("已退出")


if __name__ == "__main__":
    main()
