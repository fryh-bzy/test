#!/bin/bash
###############################################################################
# Oracle RAC 19c on Oracle Linux 8.8 (OpenStack虚拟机) —— 节点预处理一键脚本
#
# 用法：在【每一个】RAC节点（rac1、rac2）上分别执行
#   ./02-RAC预处理一键脚本.sh
#
# 与物理机/传统虚拟化环境的区别：
#   - 共享磁盘来自Cinder Multiattach卷(Ceph RBD)，设备名为 /dev/vdX 或 /dev/sdX，
#     两节点上的盘序可能不一致，脚本用 /dev/disk/by-id/<序列号> 方式固定，
#     序列号来自Cinder卷UUID，比传统scsi_id方式更稳定可靠。
#   - 云镜像通常已cloud-init初始化，网卡命名可能是 ens3/eth0，请按实际ip a结果调整。
###############################################################################
set -e

########## 用户配置区：请按实际环境修改 ##########
NODE1_NAME="rac1"
NODE1_IP="192.168.56.101"
NODE1_PRIV_IP="10.10.10.11"
NODE1_VIP="192.168.56.111"

NODE2_NAME="rac2"
NODE2_IP="192.168.56.102"
NODE2_PRIV_IP="10.10.10.12"
NODE2_VIP="192.168.56.112"

SCAN_NAME="rac-scan"
SCAN_IP1="192.168.56.121"
SCAN_IP2="192.168.56.122"
SCAN_IP3="192.168.56.123"

ORACLE_BASE="/u01/app/oracle"
GRID_BASE="/u01/app/grid"
GRID_HOME="/u01/app/19.0.0/grid"
DB_HOME="/u01/app/oracle/product/19.0.0/dbhome_1"

GRID_PWD="Oracle_2024#"
ORACLE_PWD="Oracle_2024#"

# 对应OpenStack里创建的4块共享Cinder卷名字，用于自动匹配by-id
CINDER_VOL_OCR1="rac-ocr1"
CINDER_VOL_OCR2="rac-ocr2"
CINDER_VOL_DATA1="rac-data1"
CINDER_VOL_RECO1="rac-reco1"
###################################################

echo ">>> [1/9] 配置 /etc/hosts"
cat >> /etc/hosts <<EOF

# RAC Interconnect & Public & VIP
${NODE1_IP}   ${NODE1_NAME}.localdomain   ${NODE1_NAME}
${NODE1_PRIV_IP}   ${NODE1_NAME}-priv.localdomain   ${NODE1_NAME}-priv
${NODE1_VIP}   ${NODE1_NAME}-vip.localdomain   ${NODE1_NAME}-vip

${NODE2_IP}   ${NODE2_NAME}.localdomain   ${NODE2_NAME}
${NODE2_PRIV_IP}   ${NODE2_NAME}-priv.localdomain   ${NODE2_NAME}-priv
${NODE2_VIP}   ${NODE2_NAME}-vip.localdomain   ${NODE2_NAME}-vip

# SCAN（测试环境用hosts硬编，生产必须用DNS轮询）
${SCAN_IP1}   ${SCAN_NAME}
${SCAN_IP2}   ${SCAN_NAME}
${SCAN_IP3}   ${SCAN_NAME}
EOF

echo ">>> [2/9] 关闭 firewalld，设置 SELinux 为 permissive"
systemctl disable --now firewalld || true
setenforce 0 || true
sed -i 's/^SELINUX=enforcing/SELINUX=permissive/' /etc/selinux/config

echo ">>> [3/9] 配置 yum 源并安装 oracle-database-preinstall-19c"
dnf -y install oracle-database-preinstall-19c chrony policycoreutils-python-utils cloud-utils-growpart

echo ">>> [4/9] 配置 chrony 时间同步"
systemctl enable --now chronyd
chronyc makestep || true

echo ">>> [5/9] 识别Cinder共享盘并生成udev固定别名规则"
echo "    自动扫描 /dev/disk/by-id/ 下的virtio/scsi盘标识..."
ls -la /dev/disk/by-id/ | grep -iE 'virtio|scsi' || true

cat <<'NOTE'

    OpenStack虚拟机的Cinder卷，在 /dev/disk/by-id/ 下通常表现为：
      virtio-<卷UUID前20位>   (virtio-blk方式，常见于KVM+cinder默认配置)
    或
      scsi-0QEMU_QEMU_HARDDISK_<卷UUID前20位>   (virtio-scsi方式)

    请执行以下命令，对照Cinder卷UUID找到各共享盘对应的by-id名称：
      openstack volume show rac-ocr1  -f value -c id
      openstack volume show rac-ocr2  -f value -c id
      openstack volume show rac-data1 -f value -c id
      openstack volume show rac-reco1 -f value -c id
    然后在本机执行:
      ls -la /dev/disk/by-id/ | grep <卷UUID前20位>
    确认每块盘的by-id路径后，替换下面udev规则里的 BY_ID_PLACEHOLDER。
NOTE

cat > /etc/udev/rules.d/99-oracle-asmdevices.rules <<'EOF'
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_OCR1_PLACEHOLDER*", SYMLINK+="asm-ocr1", OWNER="grid", GROUP="asmadmin", MODE="0660"
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_OCR2_PLACEHOLDER*", SYMLINK+="asm-ocr2", OWNER="grid", GROUP="asmadmin", MODE="0660"
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_DATA1_PLACEHOLDER*", SYMLINK+="asm-data1", OWNER="grid", GROUP="asmadmin", MODE="0660"
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_RECO1_PLACEHOLDER*", SYMLINK+="asm-reco1", OWNER="grid", GROUP="asmadmin", MODE="0660"
EOF

echo "    替换完成后执行: udevadm control --reload-rules && udevadm trigger"
echo "    验证: ls -la /dev/asm-*"

echo ">>> [6/9] 创建目录结构与权限"
mkdir -p ${ORACLE_BASE} ${GRID_BASE} ${GRID_HOME} ${DB_HOME}
chown -R grid:oinstall ${GRID_BASE} ${GRID_HOME}
chown -R oracle:oinstall ${ORACLE_BASE} ${DB_HOME}
chmod -R 775 /u01

echo ">>> [7/9] 设置 grid/oracle 用户密码"
echo "grid:${GRID_PWD}" | chpasswd
echo "oracle:${ORACLE_PWD}" | chpasswd

echo ">>> [8/9] 追加内核参数（preinstall包已覆盖大部分，这里做兜底补充）"
cat >> /etc/sysctl.conf <<'EOF'
fs.aio-max-nr = 1048576
fs.file-max = 6815744
kernel.shmmni = 4096
net.core.rmem_max = 4194304
net.core.wmem_max = 1048576
EOF
sysctl -p

echo ">>> [9/9] 云镜像常见项检查提醒"
cat <<'TIP'
    请额外确认（云镜像/cloud-init环境常见问题）：
      1. NetworkManager是否托管了网卡，避免cloud-init每次重启覆盖/etc/hosts或网卡配置
         (可在 /etc/cloud/cloud.cfg 中禁用 network 和 hosts 模块的重复管理：
          在 cloud_init_modules 里注释掉 - update_hostname 与 - update_etc_hosts)
      2. 私网网卡(private/互联网卡)是否设置了正确的MTU（如OpenStack网络支持9000巨帧，
         网卡上也要ip link set <私网卡> mtu 9000，且两节点必须一致）
      3. Cinder共享盘不要做fdisk分区，也不要mkfs，保持裸设备交给ASM管理
TIP

echo ""
echo "==================================================================="
echo " 本节点预处理完成。请在【另一节点】重复执行本脚本。"
echo " 两节点都完成后，请手动完成以下事项："
echo "  1. 按提示获取共享盘by-id路径，替换udev规则PLACEHOLDER，两节点保持一致"
echo "  2. 配置 grid/oracle 用户 SSH 互信"
echo "  3. 确认两节点public/private网络互通、hostname解析一致"
echo "  4. 上传解压 Grid Infrastructure / Database 安装介质到 /u01/software"
echo "  5. 执行 03-GI-DB静默安装脚本.sh"
echo "==================================================================="
