#!/usr/bin/env bash
# 00_prepare_os.sh —— OL7.9 双节点操作系统层准备
# 用法: 在 racnode1 / racnode2 上分别以 root 执行
#       LOCAL_HOST=racnode1 LOCAL_ROLE=1 ./00_prepare_os.sh
#       LOCAL_HOST=racnode2 LOCAL_ROLE=2 ./00_prepare_os.sh
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

: "${LOCAL_ROLE:?必须指定 LOCAL_ROLE=1 或 2}"

if [ "$LOCAL_ROLE" = "1" ]; then
  MY_HOST=$NODE1_HOST; MY_PUB_IP=$NODE1_PUB_IP; MY_PRIV_IP=$NODE1_PRIV_IP; MY_VIP=$NODE1_VIP
else
  MY_HOST=$NODE2_HOST; MY_PUB_IP=$NODE2_PUB_IP; MY_PRIV_IP=$NODE2_PRIV_IP; MY_VIP=$NODE2_VIP
fi

echo "==> [1/9] 主机名 & /etc/hosts"
hostnamectl set-hostname "${MY_HOST}.${DOMAIN}"
cat >> /etc/hosts <<EOF
# --- Oracle RAC ---
${NODE1_PUB_IP}   ${NODE1_HOST}.${DOMAIN}   ${NODE1_HOST}
${NODE2_PUB_IP}   ${NODE2_HOST}.${DOMAIN}   ${NODE2_HOST}
${NODE1_VIP}      ${NODE1_HOST}-vip.${DOMAIN}   ${NODE1_HOST}-vip
${NODE2_VIP}      ${NODE2_HOST}-vip.${DOMAIN}   ${NODE2_HOST}-vip
${NODE1_PRIV_IP}  ${NODE1_HOST}-priv.${DOMAIN}  ${NODE1_HOST}-priv
${NODE2_PRIV_IP}  ${NODE2_HOST}-priv.${DOMAIN}  ${NODE2_HOST}-priv
${SCAN_IP1}       ${SCAN_NAME}.${DOMAIN}  ${SCAN_NAME}
${SCAN_IP2}       ${SCAN_NAME}.${DOMAIN}  ${SCAN_NAME}
${SCAN_IP3}       ${SCAN_NAME}.${DOMAIN}  ${SCAN_NAME}
EOF

echo "==> [2/9] 网卡确认 eth0.1(公网)/eth0.4006(私网)"
nmcli con show "${PUB_NIC}"  >/dev/null 2>&1 || echo "警告: 未找到连接 ${PUB_NIC}，请确认VLAN子接口命名"
nmcli con show "${PRIV_NIC}" >/dev/null 2>&1 || echo "警告: 未找到连接 ${PRIV_NIC}，请确认VLAN子接口命名"
# 私网MTU建议调整为9000(若OpenStack底层网络/Neutron支持jumbo frame)
nmcli con modify "${PRIV_NIC}" 802-3-ethernet.mtu 9000 || true
nmcli con up "${PRIV_NIC}" || true

echo "==> [3/9] 关闭 firewalld / 置 SELinux为permissive"
systemctl disable --now firewalld || true
setenforce 0 || true
sed -i 's/^SELINUX=.*/SELINUX=permissive/' /etc/selinux/config

echo "==> [4/9] 关闭 Transparent HugePage / NUMA自动均衡"
grubby --update-kernel=ALL --args="transparent_hugepage=never numa_balancing=disable"
cat > /etc/systemd/system/disable-thp.service <<'EOF'
[Unit]
Description=Disable Transparent Huge Pages
[Service]
Type=oneshot
ExecStart=/bin/sh -c "echo never > /sys/kernel/mm/transparent_hugepage/enabled"
[Install]
WantedBy=multi-user.target
EOF
systemctl enable disable-thp.service

echo "==> [5/9] 安装 preinstall RPM 及依赖包"
yum install -y oracle-database-preinstall-19c chrony parted unzip nfs-utils \
               net-tools bind-utils sshpass expect || true

echo "==> [6/9] chrony 时间同步（Oracle Clusterware 要求节点间时钟一致）"
systemctl enable --now chronyd

echo "==> [7/9] 内核参数 (追加, preinstall包已覆盖大部分, 此处补充)"
cat >> /etc/sysctl.d/99-oracle-rac.conf <<'EOF'
fs.aio-max-nr = 1048576
fs.file-max = 6815744
kernel.panic_on_oops = 1
net.core.rmem_default = 262144
net.core.rmem_max = 4194304
net.core.wmem_default = 262144
net.core.wmem_max = 1048576
net.ipv4.conf.all.rp_filter = 2
net.ipv4.conf.default.rp_filter = 2
EOF
# 注意: kernel.shmall/kernel.shmmax/kernel.shmmni 不在此处手写固定值，
# 由 oracle-database-preinstall-19c 包根据本机实际物理内存自动计算写入
# /etc/sysctl.d/98-* ，手动覆盖过小的值会导致cluvfy PRVG-1201报错。
# 若确实要覆盖，先用 cluvfy 报错里的 Expected 值回填。
sysctl --system

echo "==> [8/9] 创建用户组 / 用户 / 目录 (与 rac_env.conf 保持一致)"
groupadd -g 54321 oinstall 2>/dev/null || true
groupadd -g 54322 dba 2>/dev/null || true
groupadd -g 54323 oper 2>/dev/null || true
groupadd -g 54324 asmadmin 2>/dev/null || true
groupadd -g 54325 asmdba 2>/dev/null || true
groupadd -g 54326 asmoper 2>/dev/null || true

id -u ${GRID_USER}   &>/dev/null || useradd -u 54331 -g oinstall -G asmadmin,asmdba,asmoper,dba ${GRID_USER}
id -u ${ORACLE_USER} &>/dev/null || useradd -u 54332 -g oinstall -G dba,oper,asmdba ${ORACLE_USER}

echo "${ROOT_PASSWD:?请export ROOT_PASSWD后运行}"   | passwd --stdin root       >/dev/null
echo "${GRID_PASSWD:?请export GRID_PASSWD后运行}"   | passwd --stdin ${GRID_USER}   >/dev/null
echo "${ORACLE_PASSWD:?请export ORACLE_PASSWD后运行}" | passwd --stdin ${ORACLE_USER} >/dev/null

mkdir -p ${INVENTORY_LOC} ${GRID_BASE} ${GRID_HOME} ${ORACLE_BASE} ${DB_HOME}
chown -R ${GRID_USER}:oinstall   ${INVENTORY_LOC} ${GRID_BASE} ${GRID_HOME}
chown -R ${ORACLE_USER}:oinstall ${ORACLE_BASE}
chmod -R 775 ${INVENTORY_LOC} ${GRID_BASE} ${ORACLE_BASE}

for u in ${GRID_USER} ${ORACLE_USER}; do
cat >> /home/${u}/.bash_profile <<EOF
export ORACLE_BASE=${ORACLE_BASE}
export ORACLE_HOME=${DB_HOME}
export GRID_HOME=${GRID_HOME}
export PATH=\$ORACLE_HOME/bin:\$GRID_HOME/bin:\$PATH
umask 022
EOF
done

echo "==> [9/9] limits.conf 补充（防止GI/DB安装阶段cluvfy报警）"
cat >> /etc/security/limits.d/oracle-rac.conf <<EOF
${GRID_USER}   soft nofile   1024
${GRID_USER}   hard nofile   65536
${ORACLE_USER} soft nofile   1024
${ORACLE_USER} hard nofile   65536
${GRID_USER}   soft nproc    16384
${ORACLE_USER} soft nproc    16384
${GRID_USER}   soft stack    10240
${ORACLE_USER} soft stack    10240
EOF

echo "节点 ${MY_HOST} 操作系统层准备完成，请reboot后再进行下一步（04脚本ssh互信）"
