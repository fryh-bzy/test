#!/usr/bin/env bash
# 03_install_grid.sh —— 在 racnode1 上以 root 执行
# 依次完成: 校验SCAN解析 -> 解压GI介质 -> 生成响应文件 -> grid用户静默安装
#           -> 两节点root脚本编排执行 -> 集群状态校验
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

echo "==> [0/6] SCAN 名称解析校验(需返回3条记录, 若无DNS则依赖/etc/hosts轮询)"
getent hosts "${SCAN_NAME}.${DOMAIN}" || { echo "SCAN解析失败，检查/etc/hosts"; exit 1; }

echo "==> [1/6] 解压 Grid 介质到 ${GRID_HOME} (grid用户)"
su - ${GRID_USER} -c "unzip -oq ${GRID_ZIP} -d ${GRID_HOME}"

echo "==> [2/6] 渲染响应文件 grid.rsp"
set -a; source "$BASEDIR/rac_env.conf"; set +a
envsubst < "$BASEDIR/grid.rsp.template" > /tmp/grid.rsp
chown ${GRID_USER}:oinstall /tmp/grid.rsp
su - ${GRID_USER} -c "cp /tmp/grid.rsp ${GRID_HOME}/grid.rsp"

echo "==> [3/6] cluvfy 预检查（不阻断，仅提示）"
su - ${GRID_USER} -c "${GRID_HOME}/runcluvfy.sh stage -pre crsinst -n ${NODE1_HOST},${NODE2_HOST} -verbose" || true

echo "==> [4/6] gridSetup.sh 静默安装（自动推送介质到${NODE2_HOST}，依赖01脚本grid用户互信）"
su - ${GRID_USER} -c "${GRID_HOME}/gridSetup.sh -silent -waitforcompletion \
    -responseFile ${GRID_HOME}/grid.rsp -ignorePrereq" || GRID_RC=$?
echo "OUI阶段返回码: ${GRID_RC:-0} (100/6表示需要执行root脚本，属正常)"

# 硬性校验：root.sh若不存在，说明OUI软件安装阶段本身就没走完，
# 不能继续跑root脚本，否则会看到"orainstRoot.sh: No such file"这类误导性级联报错
if [ ! -f "${GRID_HOME}/root.sh" ]; then
  echo "致命: ${GRID_HOME}/root.sh 不存在，GI软件安装未完成，请查看上方[FATAL]/[INS-xxxxx]具体原因"
  echo "        (常见: grid.rsp字段/枚举值错误、磁盘组发现失败、SSH互信未通过等)"
  echo "清理后重试: su - ${GRID_USER} -c \"${GRID_HOME}/deinstall/deinstall\" 或手工清空 ${GRID_HOME} 与 ${INVENTORY_LOC} 后重新解压介质"
  exit 1
fi

echo "==> [5/6] 按顺序在两节点执行 root 脚本"
for h in ${NODE1_HOST} ${NODE2_HOST}; do
  echo "  -> ${h}: orainstRoot.sh"
  ssh -o StrictHostKeyChecking=no root@${h} "${INVENTORY_LOC}/orainstRoot.sh"
done
echo "  -> ${NODE1_HOST}(首节点): root.sh"
ssh -o StrictHostKeyChecking=no root@${NODE1_HOST} "${GRID_HOME}/root.sh"
echo "  -> ${NODE2_HOST}(末节点): root.sh"
ssh -o StrictHostKeyChecking=no root@${NODE2_HOST} "${GRID_HOME}/root.sh"

echo "==> [6/6] 收尾配置工具 + 集群状态检查"
su - ${GRID_USER} -c "${GRID_HOME}/gridSetup.sh -executeConfigTools -responseFile ${GRID_HOME}/grid.rsp -silent" || true
su - ${GRID_USER} -c "${GRID_HOME}/bin/crsctl check cluster -all"
su - ${GRID_USER} -c "${GRID_HOME}/bin/crsctl stat res -t"
su - ${GRID_USER} -c "${GRID_HOME}/bin/asmcmd lsdg"

echo "Grid Infrastructure 19.3 双节点集群安装完成。"
