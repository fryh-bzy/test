#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rag_mcp_server.py (命令行参数版, Linux 环境)

把本地 RAG 检索能力封装成 MCP server,通过 stdio 传输和 Claude Code 通信。

相比早期版本的改进:
    1. 支持通过命令行参数指定索引路径、collection、embedding 模型,
       不再强制依赖环境变量(环境变量仍然支持,作为兜底/默认值)。
    2. 支持"单集合模式"和"多集合模式":
         - 只传一个 --collection: 工具函数不需要调用方指定集合名,
           行为和早期单库版本一致,简单直接。
         - 传多个 --collection(可重复传): 会暴露一个
           list_available_collections 工具,search_code 工具增加
           collection 参数,由 Claude Code 自行判断该查哪个库。
    3. 因为参数在启动命令行里,给不同知识库分别起独立的 MCP server 实例时,
       只需要改 claude mcp add 里的参数,不需要复制/修改脚本本身或
       维护多套环境变量。

依赖:
    pip install "mcp[cli]" chromadb sentence-transformers

前置条件:
    先用 build_index.py 对目标源码目录建好索引。

用法示例(单集合模式,和早期版本行为一致):
    python3 rag_mcp_server.py \\
        --index-path /opt/rag/framework_index \\
        --collection internal_framework

用法示例(多集合模式,一个 server 同时服务多个知识库):
    python3 rag_mcp_server.py \\
        --index-path /opt/rag/all_index \\
        --collection internal_framework:公司内部框架源码 \\
        --collection business_code:具体业务系统代码 \\
        --collection internal_docs:内部技术规范文档

指定 embedding 模型(本地路径或 HuggingFace 名称):
    python3 rag_mcp_server.py \\
        --index-path ./rag_index \\
        --collection internal_framework \\
        --embed-model /opt/models/bge-m3

注册进 Claude Code(Linux 下的写法,command 用虚拟环境里的绝对路径):
    claude mcp add --transport stdio --scope project framework-rag \\
      -- /home/user/rag_mcp_server/.venv/bin/python \\
         /home/user/rag_mcp_server/rag_mcp_server.py \\
         --index-path /opt/rag/framework_index \\
         --collection internal_framework
"""

import argparse
import os
import sys

import chromadb
from mcp.server.fastmcp import FastMCP
from sentence_transformers import SentenceTransformer


def parse_args():
    parser = argparse.ArgumentParser(
        description="本地 RAG 检索 MCP server",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--index-path",
        default=os.environ.get("RAG_INDEX_PATH", "./rag_index"),
        help="Chroma 索引持久化目录",
    )
    parser.add_argument(
        "--collection",
        action="append",
        dest="collections",
        default=None,
        help=(
            "要提供检索的集合,格式为 'name' 或 'name:说明文字'。"
            "可重复传该参数以支持多个集合。不指定时回退到环境变量 RAG_COLLECTION"
        ),
    )
    parser.add_argument(
        "--embed-model",
        default=os.environ.get("RAG_EMBED_MODEL", "BAAI/bge-m3"),
        help="embedding 模型名称(HuggingFace)或本地模型目录路径",
    )
    parser.add_argument(
        "--server-name",
        default=os.environ.get("RAG_SERVER_NAME", "local-rag"),
        help="MCP server 名称,会显示在 Claude Code 的 /mcp 列表里",
    )
    parser.add_argument(
        "--default-top-k",
        type=int,
        default=5,
        help="不指定 top_k 时的默认返回条数",
    )
    args = parser.parse_args()

    if not args.collections:
        env_collection = os.environ.get("RAG_COLLECTION")
        if env_collection:
            args.collections = [env_collection]
        else:
            parser.error(
                "必须至少指定一个 --collection,或设置环境变量 RAG_COLLECTION"
            )

    return args


def build_collection_registry(collections_raw):
    """把 ['name:说明', 'name2'] 这种输入解析成 {name: 说明} 字典。"""
    registry = {}
    for item in collections_raw:
        if ":" in item:
            name, desc = item.split(":", 1)
        else:
            name, desc = item, ""
        name = name.strip()
        desc = desc.strip() or f"集合 {name}"
        registry[name] = desc
    return registry


def main():
    args = parse_args()
    collections = build_collection_registry(args.collections)
    multi_mode = len(collections) > 1

    sys.stderr.write(
        f"[rag_mcp_server] index_path={args.index_path} "
        f"collections={list(collections.keys())} "
        f"embed_model={args.embed_model} multi_mode={multi_mode}\n"
    )

    mcp = FastMCP(args.server_name)

    embed_model = SentenceTransformer(args.embed_model)
    client = chromadb.PersistentClient(path=args.index_path)

    def get_collection(name):
        return client.get_collection(name)

    def do_search(query, collection_name, top_k):
        top_k = max(1, min(top_k, 20))
        try:
            coll = get_collection(collection_name)
        except Exception as exc:
            return (
                f"集合 '{collection_name}' 不存在或尚未建立索引"
                f"(请先运行 build_index.py --collection {collection_name}): {exc}"
            )

        query_embedding = embed_model.encode([query], normalize_embeddings=True)
        results = coll.query(
            query_embeddings=query_embedding.tolist(), n_results=top_k
        )

        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0] if results.get("distances") else []

        if not docs:
            return f"在集合 '{collection_name}' 中未检索到与该问题相关的内容"

        sections = []
        for idx, (doc, meta) in enumerate(zip(docs, metas)):
            dist_info = (
                f" (相似度距离: {distances[idx]:.4f})" if idx < len(distances) else ""
            )
            sections.append(
                f"### 片段 {idx + 1} - 文件: {meta.get('file', '未知')}{dist_info}\n"
                f"```\n{doc}\n```"
            )
        return "\n\n".join(sections)

    def do_list_files(collection_name, prefix):
        try:
            coll = get_collection(collection_name)
        except Exception as exc:
            return f"集合 '{collection_name}' 不存在或尚未建立索引: {exc}"

        all_data = coll.get(include=["metadatas"])
        files = set()
        for meta in all_data.get("metadatas", []):
            f = meta.get("file", "")
            if f and (not prefix or f.startswith(prefix)):
                files.add(f)

        if not files:
            return f"集合 '{collection_name}' 中没有匹配的文件"
        return "\n".join(sorted(files))

    # ----------------------------------------------------------------
    # 单集合模式:工具签名简单,不需要调用方指定 collection
    # ----------------------------------------------------------------
    if not multi_mode:
        only_collection = next(iter(collections))
        collection_desc = collections[only_collection]

        @mcp.tool()
        def search_code(query: str, top_k: int = args.default_top_k) -> str:
            f"""在知识库({collection_desc})中检索与问题最相关的代码/文档片段。

            当需要了解具体实现、接口定义、调用规范时,应优先调用此工具获取
            真实内容作为依据,而不是凭已有知识推测。

            Args:
                query: 要检索的问题或关键词
                top_k: 返回最相关的片段数量,默认 {args.default_top_k}
            """
            return do_search(query, only_collection, top_k)

        @mcp.tool()
        def list_indexed_files(prefix: str = "") -> str:
            """列出当前索引中包含的文件路径,便于确认索引范围或排查检索不到内容的问题。

            Args:
                prefix: 可选的路径前缀过滤,例如 'common/' 只看某个子目录
            """
            return do_list_files(only_collection, prefix)

    # ----------------------------------------------------------------
    # 多集合模式:先列出可用集合,再指定 collection 参数检索
    # ----------------------------------------------------------------
    else:
        @mcp.tool()
        def list_available_collections() -> str:
            """列出当前可检索的所有知识库集合及其说明。
            在调用 search_code 之前,应先调用这个工具确认该查哪个集合。
            """
            lines = [f"- {name}: {desc}" for name, desc in collections.items()]
            return "\n".join(lines)

        @mcp.tool()
        def search_code(query: str, collection: str, top_k: int = args.default_top_k) -> str:
            f"""在指定知识库集合中检索与问题最相关的代码/文档片段。

            Args:
                query: 要检索的问题或关键词
                collection: 要查询的集合名,取值见 list_available_collections 的返回结果
                top_k: 返回最相关的片段数量,默认 {args.default_top_k}
            """
            if collection not in collections:
                return (
                    f"未知集合 '{collection}',可用集合: {list(collections.keys())}"
                )
            return do_search(query, collection, top_k)

        @mcp.tool()
        def list_indexed_files(collection: str, prefix: str = "") -> str:
            """列出指定集合中包含的文件路径,便于确认索引范围或排查检索不到内容的问题。

            Args:
                collection: 要查看的集合名,取值见 list_available_collections 的返回结果
                prefix: 可选的路径前缀过滤
            """
            if collection not in collections:
                return (
                    f"未知集合 '{collection}',可用集合: {list(collections.keys())}"
                )
            return do_list_files(collection, prefix)

    mcp.run()


if __name__ == "__main__":
    main()
