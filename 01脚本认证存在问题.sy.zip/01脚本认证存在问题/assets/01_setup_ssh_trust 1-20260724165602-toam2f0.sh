#!/usr/bin/env bash
# 01_setup_ssh_trust.sh —— 在 racnode1 上执行一次即可
# 为 root / grid / oracle 三个账号在两节点间建立双向 SSH Key 互信
# 依赖 expect (00脚本已装)，不再依赖 sshpass —— OL7离线ISO源默认没有sshpass(它在EPEL里)
# 前置: export ROOT_PASSWD / GRID_PASSWD / ORACLE_PASSWD (与00脚本一致)
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

: "${ROOT_PASSWD:?}"; : "${GRID_PASSWD:?}"; : "${ORACLE_PASSWD:?}"

command -v expect >/dev/null || { echo "缺少 expect，先 yum install -y expect"; exit 1; }

# ---- 生成三个通用 expect 脚本到 /tmp，供所有用户调用 ----
cat > /tmp/_ssh_copy_id.exp <<'EOF'
#!/usr/bin/expect -f
set timeout 15
set host [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
spawn ssh-copy-id -o StrictHostKeyChecking=no ${user}@${host}
expect {
  -re "yes/no" { send "yes\r"; exp_continue }
  -re "password:" { send "${pass}\r" }
  eof
}
EOF

cat > /tmp/_scp_push.exp <<'EOF'
#!/usr/bin/expect -f
set timeout 15
set src  [lindex $argv 0]
set dst  [lindex $argv 1]
set pass [lindex $argv 2]
spawn scp -o StrictHostKeyChecking=no $src $dst
expect {
  -re "yes/no" { send "yes\r"; exp_continue }
  -re "password:" { send "${pass}\r" }
  eof
}
EOF

cat > /tmp/_ssh_pull.exp <<'EOF'
#!/usr/bin/expect -f
set timeout 15
set user [lindex $argv 0]
set host [lindex $argv 1]
set pass [lindex $argv 2]
set remotecmd [lindex $argv 3]
log_user 0
spawn ssh -o StrictHostKeyChecking=no ${user}@${host} $remotecmd
expect {
  -re "yes/no" { send "yes\r"; exp_continue }
  -re "password:" { send "${pass}\r" }
}
log_user 1
expect eof
EOF

chmod 755 /tmp/_ssh_copy_id.exp /tmp/_scp_push.exp /tmp/_ssh_pull.exp

setup_trust_for_user() {
  local user=$1 pass=$2
  echo "==> 配置 ${user} 用户互信"
  local home
  home=$(getent passwd "$user" | cut -d: -f6)
  su - "$user" -c "mkdir -p ~/.ssh && chmod 700 ~/.ssh"
  su - "$user" -c "test -f ~/.ssh/id_rsa || ssh-keygen -t rsa -N '' -f ~/.ssh/id_rsa"

  su - "$user" -c "cat > ~/.ssh/config <<'EOC'
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile=/dev/null
EOC
chmod 600 ~/.ssh/config"

  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    echo "  -> 分发公钥至 ${h}"
    su - "$user" -c "expect /tmp/_ssh_copy_id.exp ${h} ${user} '${pass}'"
  done

  # 拉取对端 authorized_keys 合并，确保 node1<->node2 互相免密（而非单向）
  su - "$user" -c "rm -f ~/.ssh/authorized_keys.merged"
  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    su - "$user" -c "expect /tmp/_ssh_pull.exp ${user} ${h} '${pass}' 'cat ~/.ssh/authorized_keys' >> ~/.ssh/authorized_keys.merged"
  done
  su - "$user" -c "grep -E '^(ssh-rsa|ssh-ed25519|ecdsa-sha2)' ~/.ssh/authorized_keys.merged | sort -u > ~/.ssh/authorized_keys; chmod 600 ~/.ssh/authorized_keys; rm -f ~/.ssh/authorized_keys.merged"

  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    su - "$user" -c "expect /tmp/_scp_push.exp ~/.ssh/authorized_keys ${user}@${h}:~/.ssh/authorized_keys '${pass}'"
  done
}

setup_trust_for_user root           "$ROOT_PASSWD"
setup_trust_for_user "$GRID_USER"   "$GRID_PASSWD"
setup_trust_for_user "$ORACLE_USER" "$ORACLE_PASSWD"

rm -f /tmp/_ssh_copy_id.exp /tmp/_scp_push.exp /tmp/_ssh_pull.exp

echo "==> 校验（应无密码提示直接返回hostname）"
for u in root "$GRID_USER" "$ORACLE_USER"; do
  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    echo -n "  $u@$h: "
    su - "$u" -c "ssh -o BatchMode=yes ${h} hostname" || echo "FAILED"
  done
done

echo "SSH互信配置完成。"
echo "注: Grid Infrastructure 19.3 也可用官方工具二次校验/补配:"
echo "  \$GRID_HOME/../sshsetup/sshUserSetup.sh -user ${GRID_USER} -hosts \"${NODE1_HOST} ${NODE2_HOST}\" -advanced -exverify -confirm"
