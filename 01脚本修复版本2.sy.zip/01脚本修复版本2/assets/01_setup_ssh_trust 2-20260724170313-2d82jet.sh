#!/usr/bin/env bash
# 01_setup_ssh_trust.sh —— 在 racnode1 上执行一次即可（sshpass版本）
# 为 root / grid / oracle 三个账号在两节点间建立双向 SSH Key 互信
# 前置: yum install -y sshpass 已完成
#       export ROOT_PASSWD / GRID_PASSWD / ORACLE_PASSWD (与00脚本一致)
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

: "${ROOT_PASSWD:?}"; : "${GRID_PASSWD:?}"; : "${ORACLE_PASSWD:?}"
command -v sshpass >/dev/null || { echo "缺少 sshpass"; exit 1; }

SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"

setup_trust_for_user() {
  local user=$1 pass=$2
  echo "==> 配置 ${user} 用户互信"
  local home
  home=$(getent passwd "$user" | cut -d: -f6)

  su - "$user" -c "mkdir -p ~/.ssh && chmod 700 ~/.ssh"
  su - "$user" -c "test -f ~/.ssh/id_rsa || ssh-keygen -t rsa -N '' -f ~/.ssh/id_rsa"

  # 让grid/oracle自身的交互式ssh也免strict检查（cluvfy/gridSetup仍靠known_hosts硬校验，见下方ssh-keyscan）
  su - "$user" -c "cat > ~/.ssh/config <<'EOC'
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile=/dev/null
EOC
chmod 600 ~/.ssh/config"

  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    echo "  -> 分发公钥至 ${h}"
    su - "$user" -c "sshpass -p '${pass}' ssh-copy-id ${SSH_OPTS} ${user}@${h}"
  done

  # 拉取对端 authorized_keys 合并，确保 node1<->node2 互相免密（而非单向）
  # 用 grep 过滤掉MOTD/banner等非公钥行，防止authorized_keys被污染
  su - "$user" -c "rm -f ~/.ssh/authorized_keys.merged"
  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    su - "$user" -c "sshpass -p '${pass}' ssh ${SSH_OPTS} ${user}@${h} 'cat ~/.ssh/authorized_keys' \
        | grep -E '^(ssh-rsa|ssh-ed25519|ecdsa-sha2)' >> ~/.ssh/authorized_keys.merged"
  done
  su - "$user" -c "sort -u ~/.ssh/authorized_keys.merged > ~/.ssh/authorized_keys; \
      chmod 600 ~/.ssh/authorized_keys; rm -f ~/.ssh/authorized_keys.merged"

  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    su - "$user" -c "sshpass -p '${pass}' scp ${SSH_OPTS} ~/.ssh/authorized_keys ${user}@${h}:~/.ssh/authorized_keys"
  done
}

setup_trust_for_user root           "$ROOT_PASSWD"
setup_trust_for_user "$GRID_USER"   "$GRID_PASSWD"
setup_trust_for_user "$ORACLE_USER" "$ORACLE_PASSWD"

# cluvfy / gridSetup 自身的SSH校验不吃 ~/.ssh/config 里的 StrictHostKeyChecking no，
# 必须真实写入 known_hosts，否则会报 PRKC-1191 / INS-44015
echo "==> 写入真实 known_hosts (grid/oracle 两用户，四个主机名)"
for u in "$GRID_USER" "$ORACLE_USER"; do
  su - "$u" -c "ssh-keyscan -t ecdsa,rsa ${NODE1_HOST} ${NODE2_HOST} ${NODE1_HOST}-priv ${NODE2_HOST}-priv >> ~/.ssh/known_hosts 2>/dev/null; sort -u -o ~/.ssh/known_hosts ~/.ssh/known_hosts"
done

echo "==> 校验（应无密码提示直接返回hostname）"
for u in root "$GRID_USER" "$ORACLE_USER"; do
  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    echo -n "  $u@$h: "
    su - "$u" -c "ssh -o BatchMode=yes ${h} hostname" || echo "FAILED"
  done
done

echo "SSH互信配置完成。"
echo "注: Grid Infrastructure 19.3 也可用官方工具二次校验/补配:"
echo "  \$GRID_HOME/../sshsetup/sshUserSetup.sh -user ${GRID_USER} -hosts \"${NODE1_HOST} ${NODE2_HOST}\" -advanced -exverify -confirm"
