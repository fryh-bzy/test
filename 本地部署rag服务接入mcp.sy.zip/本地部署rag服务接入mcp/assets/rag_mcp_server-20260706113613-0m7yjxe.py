#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rag_mcp_server.py

把本地 RAG 检索能力封装成一个 MCP server,通过 stdio 传输和 Claude Code 通信。
Claude Code 在需要了解"公司内部框架怎么用"时,会自动调用这里暴露的工具,
拿到真实代码片段作为参考,而不是凭训练记忆编造。

依赖:
    pip install "mcp[cli]" chromadb sentence-transformers

前置条件:
    先运行 build_index.py 建好本地向量索引(默认路径 ./rag_index)

环境变量(可选,便于不同项目复用同一份脚本):
    RAG_INDEX_PATH   索引目录,默认 ./rag_index
    RAG_COLLECTION   集合名称,默认 internal_framework
    RAG_EMBED_MODEL  embedding 模型名,默认 BAAI/bge-m3
"""

import os

import chromadb
from mcp.server.fastmcp import FastMCP
from sentence_transformers import SentenceTransformer

INDEX_PATH = os.environ.get("RAG_INDEX_PATH", "./rag_index")
COLLECTION_NAME = os.environ.get("RAG_COLLECTION", "internal_framework")
EMBED_MODEL_NAME = os.environ.get("RAG_EMBED_MODEL", "BAAI/bge-m3")

# MCP server 名称,会显示在 Claude Code 的 /mcp 列表里
mcp = FastMCP("framework-rag")

# 模块加载时就初始化好模型和数据库连接,避免每次调用工具都重新加载
# (embedding 模型加载本身有一定耗时,常驻进程可以避免每次请求都重新加载)
_embed_model = SentenceTransformer(EMBED_MODEL_NAME)
_client = chromadb.PersistentClient(path=INDEX_PATH)
_collection = _client.get_collection(COLLECTION_NAME)


@mcp.tool()
def search_framework_code(query: str, top_k: int = 5) -> str:
    """在公司内部框架代码库中检索与给定问题最相关的代码片段。

    当需要了解内部框架的用法、接口定义、调用规范、架构约定时,
    应优先调用此工具获取真实代码作为依据,而不是凭已有知识推测。

    Args:
        query: 要检索的问题或关键词,例如 "如何定义一个新的 Service"
        top_k: 返回最相关的代码片段数量,默认 5,建议不超过 10

    Returns:
        按相关度排序的代码片段,每段前面标注了对应的源文件路径
    """
    top_k = max(1, min(top_k, 20))

    query_embedding = _embed_model.encode(
        [query], normalize_embeddings=True
    )
    results = _collection.query(
        query_embeddings=query_embedding.tolist(),
        n_results=top_k,
    )

    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0] if results.get("distances") else []

    if not docs:
        return "未检索到相关代码,请尝试换一种问法或检查索引是否已构建。"

    sections = []
    for idx, (doc, meta) in enumerate(zip(docs, metas)):
        dist_info = f" (相似度距离: {distances[idx]:.4f})" if idx < len(distances) else ""
        sections.append(
            f"### 片段 {idx + 1} - 文件: {meta.get('file', '未知')}{dist_info}\n"
            f"```\n{doc}\n```"
        )

    return "\n\n".join(sections)


@mcp.tool()
def list_indexed_files(prefix: str = "") -> str:
    """列出当前索引中包含的源文件路径,便于确认索引范围或排查检索不到内容的问题。

    Args:
        prefix: 可选的路径前缀过滤,例如 "common/" 只看某个子目录下的文件

    Returns:
        去重后的文件路径列表
    """
    all_data = _collection.get(include=["metadatas"])
    files = set()
    for meta in all_data.get("metadatas", []):
        f = meta.get("file", "")
        if f and (not prefix or f.startswith(prefix)):
            files.add(f)

    if not files:
        return "索引为空或没有匹配的文件,请确认 build_index.py 是否已成功运行。"

    return "\n".join(sorted(files))


if __name__ == "__main__":
    mcp.run()
