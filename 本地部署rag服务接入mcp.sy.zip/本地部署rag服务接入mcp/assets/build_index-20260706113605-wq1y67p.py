#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_index.py

对公司内部框架源码建立本地向量索引(Chroma),供 rag_mcp_server.py 检索使用。

用法:
    python3 build_index.py --source /path/to/framework/src --index ./rag_index
"""

import argparse
import os

import chromadb
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer

DEFAULT_EXTENSIONS = (
    ".py", ".java", ".go", ".js", ".ts", ".cpp", ".c", ".h",
    ".md", ".rst",
)


def load_and_chunk(source_dir, extensions=DEFAULT_EXTENSIONS,
                    chunk_size=800, chunk_overlap=100):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\nclass ", "\ndef ", "\nfunction ", "\n\n", "\n", " "],
    )

    chunks = []
    for root, _, files in os.walk(source_dir):
        # 跳过常见的无关目录,减少噪音索引
        if any(skip in root for skip in
               (".git", "node_modules", "__pycache__", ".venv", "venv")):
            continue

        for fname in files:
            if not fname.endswith(extensions):
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except Exception as exc:
                print(f"[跳过] 读取失败 {fpath}: {exc}")
                continue

            if not content.strip():
                continue

            for i, chunk in enumerate(splitter.split_text(content)):
                chunks.append({
                    "content": chunk,
                    "file": os.path.relpath(fpath, source_dir),
                    "chunk_id": f"{os.path.relpath(fpath, source_dir)}::{i}",
                })
    return chunks


def build_index(chunks, index_path, collection_name, model_name, batch_size=64):
    print(f"加载 embedding 模型: {model_name} (首次运行会自动下载,请耐心等待)")
    embed_model = SentenceTransformer(model_name)

    client = chromadb.PersistentClient(path=index_path)
    # 如果集合已存在,先删除重建,避免重复索引旧数据
    try:
        client.delete_collection(collection_name)
        print(f"已删除旧集合 {collection_name}, 准备重新索引")
    except Exception:
        pass

    collection = client.create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"},
    )

    total = len(chunks)
    for i in range(0, total, batch_size):
        batch = chunks[i:i + batch_size]
        texts = [c["content"] for c in batch]
        embeddings = embed_model.encode(
            texts, normalize_embeddings=True, show_progress_bar=False
        )
        collection.add(
            embeddings=embeddings.tolist(),
            documents=texts,
            metadatas=[{"file": c["file"]} for c in batch],
            ids=[c["chunk_id"] for c in batch],
        )
        print(f"已索引 {min(i + batch_size, total)}/{total}")

    print(f"索引完成,共 {total} 个代码块,持久化目录: {index_path}")


def main():
    parser = argparse.ArgumentParser(description="构建内部框架代码的本地向量索引")
    parser.add_argument("--source", required=True, help="框架源码根目录")
    parser.add_argument("--index", default="./rag_index", help="索引持久化目录")
    parser.add_argument("--collection", default="internal_framework", help="集合名称")
    parser.add_argument(
        "--model", default="BAAI/bge-m3", help="embedding 模型名称(HuggingFace)"
    )
    parser.add_argument("--chunk-size", type=int, default=800)
    parser.add_argument("--chunk-overlap", type=int, default=100)
    args = parser.parse_args()

    print(f"扫描并切分源码目录: {args.source}")
    chunks = load_and_chunk(
        args.source, chunk_size=args.chunk_size, chunk_overlap=args.chunk_overlap
    )
    print(f"共切分出 {len(chunks)} 个代码块")

    if not chunks:
        print("未找到任何可索引的文件,请检查 --source 路径和文件后缀是否匹配")
        return

    build_index(chunks, args.index, args.collection, args.model)


if __name__ == "__main__":
    main()
