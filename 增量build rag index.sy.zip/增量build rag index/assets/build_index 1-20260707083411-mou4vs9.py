#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_index.py (增量 / 断点续跑版本)

对源码目录建立本地向量索引(Chroma),供 rag_mcp_server.py 检索使用。

相比初版的改进:
    1. 不再依赖 langchain,自带一个简化版递归切分函数,避免 langchain
       包结构频繁变动导致的 ModuleNotFoundError。
    2. 默认是"增量模式":
         - 已经索引过、且文件内容没有变化(mtime 未变)的文件会被跳过,
           不重新计算 embedding,节省时间。
         - 文件内容变化过的,会先删除它旧的 chunk,再重新索引。
         - 源码目录里已经被删除的文件,索引里对应的 chunk 也会被清理掉。
    3. 支持断点续跑:
         - 处理清单(manifest)在每处理完一个文件后就立即落盘,
           如果中途被打断(网络问题、Ctrl+C、断电等),重新运行时会自动
           跳过已经处理过的文件,只继续处理剩下的,不用从头再来。
         - 如果需要强制完全重建(比如切分参数、模型都变了),
           加 --full 参数即可清空重来。

用法示例:
    # 首次建索引 / 后续增量更新(默认行为)
    python3 build_index.py --source /path/to/framework/src --index ./rag_index

    # 强制完全重建(丢弃 manifest 和已有 collection,从头索引)
    python3 build_index.py --source /path/to/framework/src --index ./rag_index --full
"""

import argparse
import json
import os

import chromadb
from sentence_transformers import SentenceTransformer

DEFAULT_EXTENSIONS = (
    ".py", ".java", ".go", ".js", ".ts", ".cpp", ".c", ".h",
    ".md", ".rst",
)

DEFAULT_SEPARATORS = ["\nclass ", "\ndef ", "\nfunction ", "\n\n", "\n", " ", ""]

SKIP_DIRS = (".git", "node_modules", "__pycache__", ".venv", "venv")


# --------------------------------------------------------------------------
# 文本切分(自带简化版实现,不依赖 langchain)
# --------------------------------------------------------------------------

def _split_recursive(text, separators, chunk_size, chunk_overlap):
    """按分隔符优先级递归切分文本,尽量让每块接近 chunk_size 字符。"""
    if len(text) <= chunk_size:
        return [text] if text.strip() else []

    sep = separators[0]
    rest_seps = separators[1:] if len(separators) > 1 else [""]

    if sep == "":
        # 已经没有更细的分隔符可用了,按固定长度硬切,保留重叠
        chunks = []
        start = 0
        n = len(text)
        while start < n:
            end = min(start + chunk_size, n)
            chunks.append(text[start:end])
            if end >= n:
                break
            start = max(end - chunk_overlap, start + 1)
        return chunks

    parts = text.split(sep)
    merged = []
    current = ""
    for idx, part in enumerate(parts):
        piece = (sep if idx > 0 else "") + part
        if len(current) + len(piece) <= chunk_size:
            current += piece
        else:
            if current.strip():
                merged.append(current)
            if len(piece) > chunk_size:
                merged.extend(_split_recursive(piece, rest_seps, chunk_size, chunk_overlap))
                current = ""
            else:
                current = piece
    if current.strip():
        merged.append(current)

    # 简单叠加重叠:把上一块结尾的一部分内容,拼到下一块开头
    if chunk_overlap > 0 and len(merged) > 1:
        overlapped = [merged[0]]
        for i in range(1, len(merged)):
            prev_tail = merged[i - 1][-chunk_overlap:]
            overlapped.append(prev_tail + merged[i])
        merged = overlapped

    return merged


def split_text(text, chunk_size=800, chunk_overlap=100):
    return _split_recursive(text, DEFAULT_SEPARATORS, chunk_size, chunk_overlap)


# --------------------------------------------------------------------------
# 扫描源码目录
# --------------------------------------------------------------------------

def scan_source_files(source_dir, extensions=DEFAULT_EXTENSIONS):
    """扫描源码目录,返回 {relpath: mtime} 字典,用于和 manifest 比对。"""
    current_files = {}
    for root, dirs, files in os.walk(source_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        if any(skip in root for skip in SKIP_DIRS):
            continue
        for fname in files:
            if not fname.endswith(extensions):
                continue
            fpath = os.path.join(root, fname)
            relpath = os.path.relpath(fpath, source_dir)
            try:
                mtime = os.path.getmtime(fpath)
            except OSError:
                continue
            current_files[relpath] = mtime
    return current_files


def read_and_chunk_file(source_dir, relpath, chunk_size, chunk_overlap):
    fpath = os.path.join(source_dir, relpath)
    try:
        with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception as exc:
        print(f"[跳过] 读取失败 {fpath}: {exc}")
        return []

    if not content.strip():
        return []

    return split_text(content, chunk_size=chunk_size, chunk_overlap=chunk_overlap)


# --------------------------------------------------------------------------
# Manifest(处理清单)读写
# --------------------------------------------------------------------------

def manifest_path(index_path, collection_name):
    return os.path.join(index_path, f"{collection_name}.manifest.json")


def load_manifest(index_path, collection_name):
    path = manifest_path(index_path, collection_name)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        print(f"[警告] manifest 文件损坏,将视为空清单重新开始: {path}")
        return {}


def save_manifest(index_path, collection_name, manifest):
    os.makedirs(index_path, exist_ok=True)
    path = manifest_path(index_path, collection_name)
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)  # 原子替换,避免写到一半被打断导致文件损坏


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------

def remove_file_chunks(collection, relpath, chunk_count):
    """删除某个文件之前索引过的所有 chunk(用于文件被修改或被删除的情况)。"""
    if chunk_count <= 0:
        return
    ids = [f"{relpath}::{i}" for i in range(chunk_count)]
    try:
        collection.delete(ids=ids)
    except Exception as exc:
        print(f"[警告] 删除 {relpath} 的旧 chunk 时出错(可能本来就不存在): {exc}")


def index_one_file(collection, embed_model, source_dir, relpath,
                    chunk_size, chunk_overlap, batch_size=64):
    """对单个文件切分、embedding、写入 collection,返回新的 chunk 数量。"""
    chunks = read_and_chunk_file(source_dir, relpath, chunk_size, chunk_overlap)
    if not chunks:
        return 0

    for i in range(0, len(chunks), batch_size):
        batch_texts = chunks[i:i + batch_size]
        embeddings = embed_model.encode(
            batch_texts, normalize_embeddings=True, show_progress_bar=False
        )
        ids = [f"{relpath}::{i + j}" for j in range(len(batch_texts))]
        collection.add(
            embeddings=embeddings.tolist(),
            documents=batch_texts,
            metadatas=[{"file": relpath} for _ in batch_texts],
            ids=ids,
        )

    return len(chunks)


def build_index(source_dir, index_path, collection_name, model_name,
                 chunk_size, chunk_overlap, full_rebuild=False):
    print(f"加载 embedding 模型: {model_name} (首次运行可能需要下载,请耐心等待)")
    embed_model = SentenceTransformer(model_name)

    client = chromadb.PersistentClient(path=index_path)

    if full_rebuild:
        print("--full 已指定,清空旧集合和处理清单,完全重新索引")
        try:
            client.delete_collection(collection_name)
        except Exception:
            pass
        manifest = {}
    else:
        manifest = load_manifest(index_path, collection_name)

    collection = client.get_or_create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"},
    )

    print(f"扫描源码目录: {source_dir}")
    current_files = scan_source_files(source_dir)
    print(f"共发现 {len(current_files)} 个可索引文件")

    # 找出需要处理的文件:新增的 或 mtime 变化的
    to_process = []
    unchanged = 0
    for relpath, mtime in current_files.items():
        old = manifest.get(relpath)
        if old is None or old.get("mtime") != mtime:
            to_process.append(relpath)
        else:
            unchanged += 1

    # 找出已经从源码目录里消失、但 manifest 里还记录着的文件 -> 需要清理索引
    deleted_files = [r for r in manifest if r not in current_files]

    print(f"待处理(新增/变更): {len(to_process)} 个, "
          f"未变化跳过: {unchanged} 个, "
          f"待清理(已删除): {len(deleted_files)} 个")

    # 1. 清理已删除文件的旧 chunk
    for relpath in deleted_files:
        old_count = manifest.get(relpath, {}).get("chunk_count", 0)
        print(f"[清理] 源文件已不存在,移除索引: {relpath}")
        remove_file_chunks(collection, relpath, old_count)
        del manifest[relpath]
        save_manifest(index_path, collection_name, manifest)  # 每处理完一项就落盘

    if not to_process:
        print("没有需要新增或更新的文件,索引已是最新状态")
        return

    # 2. 处理新增/变更的文件(逐文件处理,处理完立即更新 manifest 并落盘,
    #    这样中途中断后重新运行,前面已完成的文件不会被重复处理)
    total = len(to_process)
    for idx, relpath in enumerate(to_process, 1):
        old_count = manifest.get(relpath, {}).get("chunk_count", 0)
        if old_count > 0:
            # 文件内容变化过,先清掉旧的 chunk,避免残留过时数据或chunk数量对不上
            remove_file_chunks(collection, relpath, old_count)

        try:
            new_count = index_one_file(
                collection, embed_model, source_dir, relpath,
                chunk_size, chunk_overlap,
            )
        except Exception as exc:
            print(f"[错误] 处理 {relpath} 失败,跳过,下次运行会重试: {exc}")
            continue

        manifest[relpath] = {
            "mtime": current_files[relpath],
            "chunk_count": new_count,
        }
        save_manifest(index_path, collection_name, manifest)

        print(f"[{idx}/{total}] 已索引: {relpath} ({new_count} 个代码块)")

    print(f"索引完成,持久化目录: {index_path}, 集合: {collection_name}")


def main():
    parser = argparse.ArgumentParser(
        description="构建/增量更新本地代码向量索引(支持断点续跑)"
    )
    parser.add_argument("--source", required=True, help="源码根目录")
    parser.add_argument("--index", default="./rag_index", help="索引持久化目录")
    parser.add_argument("--collection", default="internal_framework", help="集合名称")
    parser.add_argument(
        "--model", default="BAAI/bge-m3", help="embedding 模型名称或本地路径"
    )
    parser.add_argument("--chunk-size", type=int, default=800)
    parser.add_argument("--chunk-overlap", type=int, default=100)
    parser.add_argument(
        "--full", action="store_true",
        help="强制完全重建(清空旧集合和处理清单),默认是增量模式",
    )
    args = parser.parse_args()

    build_index(
        source_dir=args.source,
        index_path=args.index,
        collection_name=args.collection,
        model_name=args.model,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
        full_rebuild=args.full,
    )


if __name__ == "__main__":
    main()
