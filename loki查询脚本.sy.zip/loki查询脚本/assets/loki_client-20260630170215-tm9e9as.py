#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Loki HTTP API 调用示例
功能:
    1. 获取 Loki 配置信息
    2. 获取所有标签(label)名称
    3. 获取指定标签的所有取值
    4. 按 LogQL 查询具体日志(支持时间范围 / 关键字过滤)
依赖:
    pip install requests --break-system-packages
"""

import requests
import time
import json
from datetime import datetime, timedelta

# ========== 基础配置 ==========
LOKI_BASE_URL = "http://192.168.2.121:3100"   # 按实际 Loki 地址修改
TIMEOUT = 10


class LokiClient:
    def __init__(self, base_url=LOKI_BASE_URL, timeout=TIMEOUT, headers=None):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.headers = headers or {}
        # 如果 Loki 开启了多租户(X-Scope-OrgID),可以在这里加上
        # self.headers["X-Scope-OrgID"] = "fake"

    # -------------------- 健康检查 --------------------
    def is_ready(self):
        url = f"{self.base_url}/ready"
        try:
            resp = requests.get(url, headers=self.headers, timeout=self.timeout)
            return resp.status_code == 200
        except requests.exceptions.RequestException as e:
            print(f"[ERROR] Loki 不可达: {e}")
            return False

    # -------------------- 获取配置信息 --------------------
    def get_config(self):
        """
        获取 Loki 当前运行配置(等价于 loki -print-config-stderr 输出)
        """
        url = f"{self.base_url}/config"
        resp = requests.get(url, headers=self.headers, timeout=self.timeout)
        resp.raise_for_status()
        return resp.text  # 返回的是 yaml 格式文本

    # -------------------- 获取所有标签 --------------------
    def get_labels(self, start=None, end=None):
        """
        获取当前所有日志流中存在的标签名,例如: job, namespace, pod, container 等
        """
        url = f"{self.base_url}/loki/api/v1/labels"
        params = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        resp = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json().get("data", [])

    # -------------------- 获取指定标签的所有取值 --------------------
    def get_label_values(self, label_name, start=None, end=None):
        """
        例如获取 job 标签下都有哪些值: get_label_values("job")
        """
        url = f"{self.base_url}/loki/api/v1/label/{label_name}/values"
        params = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        resp = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json().get("data", [])

    # -------------------- 查询日志(范围查询,最常用) --------------------
    def query_range(self, logql, start=None, end=None, limit=100, direction="backward", step=None):
        """
        logql:    LogQL 查询语句,例如 '{job="varlogs"}' 或带过滤
                  '{namespace="ceph", pod=~"rgw.*"} |= "error"'
        start/end: 纳秒级时间戳(int),不传则默认查最近1小时
        limit:    返回条数上限
        direction: backward(从新到旧) / forward(从旧到新)
        """
        url = f"{self.base_url}/loki/api/v1/query_range"

        if end is None:
            end = int(time.time() * 1e9)
        if start is None:
            start = end - int(timedelta(hours=1).total_seconds() * 1e9)

        params = {
            "query": logql,
            "start": start,
            "end": end,
            "limit": limit,
            "direction": direction,
        }
        if step:
            params["step"] = step

        resp = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    # -------------------- 即时查询(单点) --------------------
    def query_instant(self, logql, time_ns=None, limit=100):
        url = f"{self.base_url}/loki/api/v1/query"
        if time_ns is None:
            time_ns = int(time.time() * 1e9)
        params = {
            "query": logql,
            "time": time_ns,
            "limit": limit,
        }
        resp = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    # -------------------- 索引统计信息 --------------------
    def index_stats(self, logql_matcher, start=None, end=None):
        """
        查询某个标签匹配范围内的流数量、chunk数量、日志条数、字节数等统计信息
        logql_matcher 例如: '{namespace="ceph"}'
        """
        url = f"{self.base_url}/loki/api/v1/index/stats"
        if end is None:
            end = int(time.time() * 1e9)
        if start is None:
            start = end - int(timedelta(hours=1).total_seconds() * 1e9)
        params = {"query": logql_matcher, "start": start, "end": end}
        resp = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()


def pretty_print_logs(result_json):
    """
    将 query_range / query 返回的结果整理打印
    """
    data = result_json.get("data", {})
    result = data.get("result", [])
    if not result:
        print("未查询到任何日志")
        return

    for stream in result:
        labels = stream.get("stream", {})
        print(f"\n=== 标签: {labels} ===")
        for entry in stream.get("values", []):
            ts_ns, line = entry
            ts = datetime.fromtimestamp(int(ts_ns) / 1e9)
            print(f"[{ts.strftime('%Y-%m-%d %H:%M:%S.%f')}] {line}")


if __name__ == "__main__":
    client = LokiClient(LOKI_BASE_URL)

    # 1. 健康检查
    if not client.is_ready():
        print("Loki 服务未就绪,请检查地址或服务状态")
        exit(1)
    print("[OK] Loki 已就绪")

    # 2. 获取配置信息(可选,用于排查 storage/schema 配置)
    try:
        config_text = client.get_config()
        print("\n===== Loki 当前配置(节选前20行) =====")
        print("\n".join(config_text.splitlines()[:20]))
    except Exception as e:
        print(f"获取配置失败: {e}")

    # 3. 获取所有标签名
    labels = client.get_labels()
    print(f"\n当前所有标签名: {labels}")

    # 4. 获取某个标签(如 job)的所有取值
    if "job" in labels:
        job_values = client.get_label_values("job")
        print(f"job 标签的取值: {job_values}")

    # 5. 查询最近 30 分钟某个 job 的日志,并按关键字过滤(如 error)
    end_ns = int(time.time() * 1e9)
    start_ns = end_ns - int(timedelta(minutes=30).total_seconds() * 1e9)

    logql = '{job="varlogs"} |= "error"'   # 按需修改为你实际的标签匹配条件
    try:
        result = client.query_range(logql, start=start_ns, end=end_ns, limit=50)
        pretty_print_logs(result)
    except requests.exceptions.HTTPError as e:
        print(f"查询日志失败: {e}, 响应内容: {e.response.text if e.response else ''}")
