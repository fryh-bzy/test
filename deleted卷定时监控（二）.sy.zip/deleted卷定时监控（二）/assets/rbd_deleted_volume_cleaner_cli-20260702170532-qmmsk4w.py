#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rbd_deleted_volume_cleaner_cli.py

不依赖 python3-rados / python3-rbd 这类 C 扩展绑定,而是通过
subprocess 调用系统上的 `rbd` 命令行工具来完成同样的清理逻辑:

    1. `rbd ls -p <pool> --format json`
       列出 pool 中所有镜像,筛选出以 .deleted 结尾的卷

    2. `rbd snap ls <pool>/<image> --format json`
       列出该卷的所有快照

    3. `rbd children <pool>/<image>@<snap> --format json`
       检查该快照是否还有 clone 依赖(children)

    4. 若没有 children:
         - 若快照是 protected 状态: `rbd snap unprotect ...`
         - `rbd snap rm ...`

    5. 该卷所有快照都清理完之后: `rbd rm <pool>/<image>`

依赖:
    - 系统已安装 ceph 客户端,能在命令行直接执行 `rbd` 命令
      (Debian/Ubuntu: apt install ceph-common; RHEL: yum install ceph-common)
    - 运行本脚本的用户对目标 ceph 集群/pool 有相应读写权限
      (通常通过 --conf 和 --name 指定,如 client.cinder)

用法示例:
    # 先 dry-run 看一遍会做什么,不会真正执行任何命令
    python3 rbd_deleted_volume_cleaner_cli.py --pool volumes --dry-run --once

    # 指定 ceph 配置和客户端身份,真正跑一次
    python3 rbd_deleted_volume_cleaner_cli.py \
        --pool volumes \
        --conf /etc/ceph/ceph.conf \
        --name client.cinder \
        --once

    # 常驻循环,每 300 秒扫描一次
    python3 rbd_deleted_volume_cleaner_cli.py \
        --pool volumes --name client.cinder --interval 300
"""

import argparse
import json
import logging
import shutil
import signal
import subprocess
import sys
import time


LOG = logging.getLogger("rbd_deleted_volume_cleaner_cli")

_SHOULD_STOP = False


def _handle_signal(signum, frame):
    global _SHOULD_STOP
    LOG.info("收到信号 %s, 将在本轮扫描结束后退出", signum)
    _SHOULD_STOP = True


class RbdCommandError(Exception):
    """rbd 命令执行失败,且不是我们已知可以安全忽略的错误"""

    def __init__(self, returncode, stderr):
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(
            "rbd command failed (rc=%s): %s" % (returncode, stderr.strip())
        )


class RbdCLI(object):
    """封装 rbd 命令行调用的小工具类"""

    def __init__(self, conf=None, name=None, keyring=None, timeout=60):
        self.conf = conf
        self.name = name
        self.keyring = keyring
        self.timeout = timeout

        rbd_path = shutil.which("rbd")
        if rbd_path is None:
            LOG.error(
                "未找到 rbd 命令,请先安装 ceph 客户端 "
                "(apt/yum install ceph-common)"
            )
            sys.exit(1)
        self.rbd_path = rbd_path

    def _base_args(self):
        args = [self.rbd_path]
        if self.conf:
            args += ["-c", self.conf]
        if self.name:
            args += ["--name", self.name]
        if self.keyring:
            args += ["--keyring", self.keyring]
        return args

    def _run(self, extra_args):
        cmd = self._base_args() + extra_args
        LOG.debug("执行命令: %s", " ".join(cmd))
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self.timeout,
            )
        except subprocess.TimeoutExpired:
            raise RbdCommandError(-1, "命令执行超时: %s" % " ".join(cmd))
        return proc.returncode, proc.stdout, proc.stderr

    def run_json(self, extra_args, ignore_errors=()):
        """执行带 --format json 的命令并解析结果。

        ignore_errors: 一个字符串元组,如果 stderr 中包含这些子串之一,
        视为"预期内的可忽略错误",返回 None 而不抛异常。
        比如 "No such file or directory" 表示对象已不存在。
        """
        rc, stdout, stderr = self._run(extra_args + ["--format", "json"])
        if rc != 0:
            for pattern in ignore_errors:
                if pattern in stderr:
                    LOG.debug("命令返回可忽略错误: %s", stderr.strip())
                    return None
            raise RbdCommandError(rc, stderr)

        stdout = stdout.strip()
        if not stdout:
            return []
        try:
            return json.loads(stdout)
        except ValueError:
            LOG.error("解析 JSON 失败, 原始输出: %s", stdout)
            raise

    def run_plain(self, extra_args, ignore_errors=()):
        """执行不需要 JSON 输出的命令,比如 snap unprotect / snap rm / rm。

        返回 True 表示成功或被认定为可忽略地"跳过",
        返回 False 表示遇到需要人工关注的错误(已记录日志)。
        """
        rc, stdout, stderr = self._run(extra_args)
        if rc == 0:
            return True

        for pattern in ignore_errors:
            if pattern in stderr:
                LOG.info("忽略预期内的错误: %s", stderr.strip())
                return True

        LOG.error(
            "命令执行失败 (rc=%s): %s | stderr: %s",
            rc, " ".join(extra_args), stderr.strip(),
        )
        return False

    # ---- 具体业务操作的封装 ----

    def list_images(self, pool):
        return self.run_json(["ls", "-p", pool]) or []

    def list_snaps(self, pool, image):
        result = self.run_json(
            ["snap", "ls", "%s/%s" % (pool, image)],
            ignore_errors=("No such file or directory",),
        )
        return result or []

    def list_children(self, pool, image, snap):
        result = self.run_json(
            ["children", "%s/%s@%s" % (pool, image, snap)],
            ignore_errors=(
                "No such file or directory",
                "is not protected",  # 部分版本 children 要求快照 protected
            ),
        )
        return result or []

    def unprotect_snap(self, pool, image, snap, dry_run):
        spec = "%s/%s@%s" % (pool, image, snap)
        if dry_run:
            LOG.info("[DRY-RUN] rbd snap unprotect %s", spec)
            return True
        LOG.info("unprotect 快照 %s", spec)
        return self.run_plain(
            ["snap", "unprotect", spec],
            ignore_errors=(
                "No such file or directory",
                "not protected",
            ),
        )

    def remove_snap(self, pool, image, snap, dry_run):
        spec = "%s/%s@%s" % (pool, image, snap)
        if dry_run:
            LOG.info("[DRY-RUN] rbd snap rm %s", spec)
            return True
        LOG.info("删除快照 %s", spec)
        return self.run_plain(
            ["snap", "rm", spec],
            ignore_errors=("No such file or directory",),
        )

    def remove_image(self, pool, image, dry_run):
        spec = "%s/%s" % (pool, image)
        if dry_run:
            LOG.info("[DRY-RUN] rbd rm %s", spec)
            return True
        LOG.info("删除卷 %s", spec)
        return self.run_plain(
            ["rm", spec],
            ignore_errors=("No such file or directory",),
        )


def cleanup_one_volume(cli, pool, image, dry_run):
    """处理单个 .deleted 卷,返回 True 表示已无快照残留,可以删除卷本身"""
    try:
        snaps = cli.list_snaps(pool, image)
    except RbdCommandError as exc:
        LOG.error("列出 %s/%s 的快照失败: %s", pool, image, exc)
        return False

    remaining = 0

    for snap in snaps:
        snap_name = snap.get("name")
        if not snap_name:
            continue

        try:
            children = cli.list_children(pool, image, snap_name)
        except RbdCommandError as exc:
            LOG.error(
                "检查 %s/%s@%s 的 children 失败: %s",
                pool, image, snap_name, exc,
            )
            remaining += 1
            continue

        if children:
            LOG.info(
                "%s/%s@%s 仍被 %d 个卷依赖,暂不清理: %s",
                pool, image, snap_name, len(children), children,
            )
            remaining += 1
            continue

        is_protected = str(snap.get("protected", "false")).lower() == "true"

        if is_protected:
            ok = cli.unprotect_snap(pool, image, snap_name, dry_run)
            if not ok:
                remaining += 1
                continue

        ok = cli.remove_snap(pool, image, snap_name, dry_run)
        if not ok:
            remaining += 1

    return remaining == 0


def run_once(cli, pool, suffix, dry_run):
    LOG.info("开始扫描 pool=%s 中的 *%s 卷 (dry_run=%s)", pool, suffix, dry_run)

    try:
        all_images = cli.list_images(pool)
    except RbdCommandError as exc:
        LOG.error("列出 pool %s 中的镜像失败: %s", pool, exc)
        return

    target_images = [name for name in all_images if name.endswith(suffix)]
    LOG.info("本轮发现 %d 个待检查的卷", len(target_images))

    cleaned = 0
    for image in target_images:
        no_snaps_left = cleanup_one_volume(cli, pool, image, dry_run)
        if no_snaps_left:
            if cli.remove_image(pool, image, dry_run):
                cleaned += 1

    LOG.info(
        "本轮扫描结束, %d/%d 个卷已清理或达到可删除条件",
        cleaned, len(target_images),
    )


def main():
    parser = argparse.ArgumentParser(
        description="通过 rbd 命令行工具定时清理 .deleted 卷"
    )
    parser.add_argument("--pool", required=True, help="RBD pool 名称,如 volumes")
    parser.add_argument("--conf", default=None, help="ceph 配置文件路径,如 /etc/ceph/ceph.conf")
    parser.add_argument(
        "--name", default=None, help="ceph 客户端身份,如 client.cinder"
    )
    parser.add_argument("--keyring", default=None, help="keyring 文件路径(可选)")
    parser.add_argument(
        "--suffix", default=".deleted", help="待清理卷的名称后缀,默认 .deleted"
    )
    parser.add_argument(
        "--interval", type=int, default=300, help="扫描间隔秒数,默认 300"
    )
    parser.add_argument("--once", action="store_true", help="只扫描一轮就退出")
    parser.add_argument(
        "--dry-run", action="store_true",
        help="只打印将要执行的 rbd 命令,不实际执行 unprotect/rm",
    )
    parser.add_argument("--log-file", default=None, help="日志文件路径")
    parser.add_argument("--verbose", action="store_true", help="输出 DEBUG 日志")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        filename=args.log_file,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    if args.dry_run:
        LOG.warning("当前处于 DRY-RUN 模式,不会执行任何实际的 unprotect/rm 命令")

    cli = RbdCLI(conf=args.conf, name=args.name, keyring=args.keyring)

    if args.once:
        run_once(cli, args.pool, args.suffix, args.dry_run)
        return

    LOG.info("进入循环模式,扫描间隔 %d 秒,Ctrl+C 可安全退出", args.interval)
    while not _SHOULD_STOP:
        try:
            run_once(cli, args.pool, args.suffix, args.dry_run)
        except Exception:
            LOG.exception("本轮扫描出现未捕获异常,等待下一轮重试")

        for _ in range(args.interval):
            if _SHOULD_STOP:
                break
            time.sleep(1)

    LOG.info("已退出")


if __name__ == "__main__":
    main()
