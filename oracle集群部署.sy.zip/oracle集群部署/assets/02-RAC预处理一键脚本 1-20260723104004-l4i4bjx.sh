#!/bin/bash
###############################################################################
# Oracle RAC 19c on Oracle Linux 8.8 (OpenStack单宿主机+单网卡Trunk) —— 节点预处理脚本
#
# 用法：在【每一个】RAC节点（rac1、rac2）上分别执行，先改"用户配置区"参数
#   ./02-RAC预处理一键脚本.sh
#
# 本版本特点：
#   - 只有一张物理网卡 ens3(请按实际ip a核实)，Neutron Trunk把VLAN1(public)和
#     VLAN4006(private)打标签透传到这张网卡，本机需要自己起802.1Q子接口来分离流量
#   - 单宿主机场景，不做反亲和相关处理（本来就没有）
#   - 共享盘依然来自Cinder Multiattach卷(Ceph RBD)，处理方式不变
###############################################################################
set -e

########## 用户配置区：请按实际环境修改 ##########
BASE_NIC="ens3"           # 物理网卡名，请用 ip a 核实，云镜像常见 ens3/eth0
VLAN_PUBLIC_ID=1
VLAN_PRIVATE_ID=4006

# 本节点信息：脚本会根据主机名自动匹配public/private IP，若做成通用脚本可按需改成传参方式
NODE1_NAME="rac1"
NODE1_IP="192.168.56.101"
NODE1_PRIV_IP="10.10.10.11"
NODE1_VIP="192.168.56.111"

NODE2_NAME="rac2"
NODE2_IP="192.168.56.102"
NODE2_PRIV_IP="10.10.10.12"
NODE2_VIP="192.168.56.112"

SCAN_NAME="rac-scan"
SCAN_IP1="192.168.56.121"
SCAN_IP2="192.168.56.122"
SCAN_IP3="192.168.56.123"

ORACLE_BASE="/u01/app/oracle"
GRID_BASE="/u01/app/grid"
GRID_HOME="/u01/app/19.0.0/grid"
DB_HOME="/u01/app/oracle/product/19.0.0/dbhome_1"

GRID_PWD="Oracle_2024#"
ORACLE_PWD="Oracle_2024#"
###################################################

CURRENT_HOST=$(hostname -s)
if [ "$CURRENT_HOST" == "$NODE1_NAME" ]; then
  MY_PUB_IP="$NODE1_IP"
  MY_PRIV_IP="$NODE1_PRIV_IP"
elif [ "$CURRENT_HOST" == "$NODE2_NAME" ]; then
  MY_PUB_IP="$NODE2_IP"
  MY_PRIV_IP="$NODE2_PRIV_IP"
else
  echo "错误：当前主机名 $CURRENT_HOST 既不是 $NODE1_NAME 也不是 $NODE2_NAME，请先设置正确主机名"
  echo "  hostnamectl set-hostname ${NODE1_NAME}   # 或 ${NODE2_NAME}"
  exit 1
fi

echo ">>> [1/10] 配置 /etc/hosts"
cat >> /etc/hosts <<EOF

# RAC Interconnect & Public & VIP
${NODE1_IP}   ${NODE1_NAME}.localdomain   ${NODE1_NAME}
${NODE1_PRIV_IP}   ${NODE1_NAME}-priv.localdomain   ${NODE1_NAME}-priv
${NODE1_VIP}   ${NODE1_NAME}-vip.localdomain   ${NODE1_NAME}-vip

${NODE2_IP}   ${NODE2_NAME}.localdomain   ${NODE2_NAME}
${NODE2_PRIV_IP}   ${NODE2_NAME}-priv.localdomain   ${NODE2_NAME}-priv
${NODE2_VIP}   ${NODE2_NAME}-vip.localdomain   ${NODE2_NAME}-vip

# SCAN（测试环境用hosts硬编，生产必须用DNS轮询）
${SCAN_IP1}   ${SCAN_NAME}
${SCAN_IP2}   ${SCAN_NAME}
${SCAN_IP3}   ${SCAN_NAME}
EOF

echo ">>> [2/10] 关闭 firewalld，设置 SELinux 为 permissive"
systemctl disable --now firewalld || true
setenforce 0 || true
sed -i 's/^SELINUX=enforcing/SELINUX=permissive/' /etc/selinux/config

echo ">>> [3/10] 安装依赖包（8021q模块 + preinstall包 + NetworkManager工具）"
dnf -y install oracle-database-preinstall-19c chrony policycoreutils-python-utils \
  NetworkManager-config-server cloud-utils-growpart

modprobe 8021q
echo "8021q" > /etc/modules-load.d/8021q.conf

echo ">>> [4/10] 配置VLAN子接口 ${BASE_NIC}.${VLAN_PUBLIC_ID}（public）"
nmcli connection delete "${BASE_NIC}.${VLAN_PUBLIC_ID}" 2>/dev/null || true
nmcli connection add type vlan con-name "${BASE_NIC}.${VLAN_PUBLIC_ID}" \
  ifname "${BASE_NIC}.${VLAN_PUBLIC_ID}" dev "${BASE_NIC}" id ${VLAN_PUBLIC_ID} \
  ip4 ${MY_PUB_IP}/24 gw4 192.168.56.1
nmcli connection modify "${BASE_NIC}.${VLAN_PUBLIC_ID}" connection.autoconnect yes

echo ">>> [5/10] 配置VLAN子接口 ${BASE_NIC}.${VLAN_PRIVATE_ID}（private/互联，无需网关）"
nmcli connection delete "${BASE_NIC}.${VLAN_PRIVATE_ID}" 2>/dev/null || true
nmcli connection add type vlan con-name "${BASE_NIC}.${VLAN_PRIVATE_ID}" \
  ifname "${BASE_NIC}.${VLAN_PRIVATE_ID}" dev "${BASE_NIC}" id ${VLAN_PRIVATE_ID} \
  ip4 ${MY_PRIV_IP}/24
nmcli connection modify "${BASE_NIC}.${VLAN_PRIVATE_ID}" connection.autoconnect yes
# 互联网络一般不需要默认路由，避免和public网关冲突
nmcli connection modify "${BASE_NIC}.${VLAN_PRIVATE_ID}" ipv4.never-default yes

echo ">>> [6/10] 启用两个VLAN子接口"
nmcli connection up "${BASE_NIC}.${VLAN_PUBLIC_ID}"
nmcli connection up "${BASE_NIC}.${VLAN_PRIVATE_ID}"

echo "    当前网络状态："
ip -br addr show | grep -E "${BASE_NIC}"

echo ">>> [7/10] 配置 chrony 时间同步"
systemctl enable --now chronyd
chronyc makestep || true

echo ">>> [8/10] 识别Cinder共享盘并生成udev固定别名规则"
ls -la /dev/disk/by-id/ | grep -iE 'virtio|scsi' || true

cat <<'NOTE'

    请对照Cinder卷UUID找到各共享盘对应的by-id名称：
      openstack volume show rac-ocr1  -f value -c id
      openstack volume show rac-ocr2  -f value -c id
      openstack volume show rac-data1 -f value -c id
      openstack volume show rac-reco1 -f value -c id
    在本机执行:
      ls -la /dev/disk/by-id/ | grep <卷UUID前20位>
    确认后替换下面udev规则里的 BY_ID_PLACEHOLDER。
NOTE

cat > /etc/udev/rules.d/99-oracle-asmdevices.rules <<'EOF'
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_OCR1_PLACEHOLDER*", SYMLINK+="asm-ocr1", OWNER="grid", GROUP="asmadmin", MODE="0660"
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_OCR2_PLACEHOLDER*", SYMLINK+="asm-ocr2", OWNER="grid", GROUP="asmadmin", MODE="0660"
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_DATA1_PLACEHOLDER*", SYMLINK+="asm-data1", OWNER="grid", GROUP="asmadmin", MODE="0660"
KERNEL=="vd*|sd*", SUBSYSTEM=="block", ENV{DEVLINKS}=="*BY_ID_RECO1_PLACEHOLDER*", SYMLINK+="asm-reco1", OWNER="grid", GROUP="asmadmin", MODE="0660"
EOF
echo "    替换完成后执行: udevadm control --reload-rules && udevadm trigger"
echo "    验证: ls -la /dev/asm-*"

echo ">>> [9/10] 创建目录结构、权限、grid/oracle密码"
mkdir -p ${ORACLE_BASE} ${GRID_BASE} ${GRID_HOME} ${DB_HOME}
chown -R grid:oinstall ${GRID_BASE} ${GRID_HOME}
chown -R oracle:oinstall ${ORACLE_BASE} ${DB_HOME}
chmod -R 775 /u01
echo "grid:${GRID_PWD}" | chpasswd
echo "oracle:${ORACLE_PWD}" | chpasswd

echo ">>> [10/10] 追加内核参数"
cat >> /etc/sysctl.conf <<'EOF'
fs.aio-max-nr = 1048576
fs.file-max = 6815744
kernel.shmmni = 4096
net.core.rmem_max = 4194304
net.core.wmem_max = 1048576
EOF
sysctl -p

echo ""
echo "==================================================================="
echo " 本节点($CURRENT_HOST)预处理完成。请在【另一节点】重复执行本脚本。"
echo " 两节点都完成后，请手动完成以下事项："
echo "  1. 用 'ping ${NODE1_PRIV_IP}' / 'ping ${NODE2_PRIV_IP}' 互相验证私网VLAN(4006)通"
echo "  2. 用 'ping ${NODE1_IP}' / 'ping ${NODE2_IP}' 互相验证公网VLAN(1)通"
echo "  3. 按提示获取共享盘by-id路径，替换udev规则PLACEHOLDER，两节点保持一致"
echo "  4. 配置 grid/oracle 用户 SSH 互信"
echo "  5. 上传解压 Grid Infrastructure / Database 安装介质到 /u01/software"
echo "  6. 执行 03-GI-DB静默安装脚本.sh"
echo "==================================================================="
