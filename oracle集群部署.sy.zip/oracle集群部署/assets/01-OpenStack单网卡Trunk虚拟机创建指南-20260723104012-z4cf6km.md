# Oracle RAC on OL8.8 —— OpenStack单网卡Trunk(VLAN演练)虚拟机创建指南

适用场景：**单宿主机**、每台VM**只有一张vNIC**，通过 Neutron **Trunk Port** 承载两个VLAN：
- VLAN 1  → Public网络（对外/管理/VIP/SCAN）
- VLAN 4006 → Private网络（RAC互联心跳）

Guest OS内用 `ens3.1` / `ens3.4006` 两个802.1Q子接口分别对应上述两个VLAN。

---

## 一、和之前方案的差异说明

| 项目 | 之前(双网卡+反亲和) | 本次(单网卡Trunk+单宿主机) |
|---|---|---|
| 宿主机 | 建议多台，反亲和 | 只有1台，**不做反亲和**，两节点共享同一故障域，这是演练环境的已知限制（前面已说明） |
| Nova网卡数 | 2个（public+private各一个port） | **1个**（一个trunk parent port） |
| VLAN隔离 | 两个独立Neutron网络+两个port | 同一个port上用Neutron **Trunk的两个subport**分别打VLAN 1 / VLAN 4006标签 |
| 安全组 | 两个port各挂各的SG | **trunk的两个subport本质仍是独立port对象**，依然可以分别挂不同安全组（这点比"单port多IP"的方案更规范，SG不用合并） |
| Guest网卡配置 | ens3(public) + ens4(private) | ens3(物理口本身不用) + **ens3.1**(public) + **ens3.4006**(private) |

> 前提：Neutron要开启了trunk service plugin。可先检查：
> ```bash
> openstack extension list --network -f value -c Name | grep -i trunk
> ```
> 如果没有，需要请OpenStack管理员在 `/etc/neutron/neutron.conf` 的 `service_plugins` 里加上 `trunk` 并重启neutron-server，这是平台侧配置，不是租户能自己开的。

---

## 二、准备工作（同之前，Flavor/镜像/密钥不变）

```bash
openstack image create "OL8.8-cloud" \
  --file OracleLinux-8.8-x86_64-cloud.qcow2 \
  --disk-format qcow2 --container-format bare --public

openstack flavor create rac-flavor --ram 16384 --disk 60 --vcpus 4

openstack keypair create rac-key > ~/rac-key.pem
chmod 600 ~/rac-key.pem
```

> 单宿主机场景**不需要**创建 `server group --policy anti-affinity`，因为只有一台宿主机，创建了也没有意义。

---

## 三、创建承载VLAN的两个租户网络

这两个网络本身用什么承载方式(vxlan/vlan/flat)都行，因为**真正到达VM网卡的VLAN tag是trunk subport上单独指定的**，与网络自身的底层封装无关。

```bash
# Public
openstack network create rac-public-net
openstack subnet create rac-public-subnet \
  --network rac-public-net \
  --subnet-range 192.168.56.0/24 \
  --allocation-pool start=192.168.56.100,end=192.168.56.130 \
  --dns-nameserver 192.168.56.2

# Private(互联)
openstack network create rac-priv-net
openstack subnet create rac-priv-subnet \
  --network rac-priv-net \
  --subnet-range 10.10.10.0/24 \
  --no-dhcp

# Trunk parent口挂的"占位网络"（不对外使用，仅满足parent port必须属于某网络的要求）
openstack network create rac-trunk-native-net
openstack subnet create rac-trunk-native-subnet \
  --network rac-trunk-native-net \
  --subnet-range 172.16.0.0/29 --no-dhcp
```

### 安全组（和之前一样，分别建）
```bash
openstack security group create rac-public-sg
openstack security group rule create rac-public-sg --protocol tcp --dst-port 22
openstack security group rule create rac-public-sg --protocol tcp --dst-port 1521:1522
openstack security group rule create rac-public-sg --protocol tcp --dst-port 6100:6200
openstack security group rule create rac-public-sg --protocol icmp

openstack security group create rac-priv-sg
openstack security group rule create rac-priv-sg --protocol tcp --dst-port 1:65535 --remote-ip 10.10.10.0/24
openstack security group rule create rac-priv-sg --protocol udp --dst-port 1:65535 --remote-ip 10.10.10.0/24
openstack security group rule create rac-priv-sg --protocol icmp --remote-ip 10.10.10.0/24
```

---

## 四、为每台VM创建Trunk（parent port + 2个subport）

### 4.1 节点1（rac1）
```bash
# 1) parent port（占位，走native网络，不打tag）
openstack port create rac1-parent-port --network rac-trunk-native-net

# 2) 两个subport：分别属于public/private网络，并指定固定IP
openstack port create rac1-public-port  --network rac-public-net  --fixed-ip subnet=rac-public-subnet,ip-address=192.168.56.101 --security-group rac-public-sg
openstack port create rac1-priv-port    --network rac-priv-net    --fixed-ip subnet=rac-priv-subnet,ip-address=10.10.10.11    --security-group rac-priv-sg

# 3) 建trunk，绑定parent + 两个subport，指定VLAN tag（1 和 4006）
openstack network trunk create --parent-port rac1-parent-port rac1-trunk
openstack network trunk set --subport port=rac1-public-port,segmentation-type=vlan,segmentation-id=1    rac1-trunk
openstack network trunk set --subport port=rac1-priv-port,segmentation-type=vlan,segmentation-id=4006   rac1-trunk

# 4) 用parent port创建VM（只有这一个port，VLAN都靠trunk转发）
openstack server create rac1 \
  --image "OL8.8-cloud" \
  --flavor rac-flavor \
  --key-name rac-key \
  --nic port-id=rac1-parent-port \
  --wait
```

### 4.2 节点2（rac2），同样流程
```bash
openstack port create rac2-parent-port --network rac-trunk-native-net

openstack port create rac2-public-port --network rac-public-net --fixed-ip subnet=rac-public-subnet,ip-address=192.168.56.102 --security-group rac-public-sg
openstack port create rac2-priv-port   --network rac-priv-net   --fixed-ip subnet=rac-priv-subnet,ip-address=10.10.10.12    --security-group rac-priv-sg

openstack network trunk create --parent-port rac2-parent-port rac2-trunk
openstack network trunk set --subport port=rac2-public-port,segmentation-type=vlan,segmentation-id=1  rac2-trunk
openstack network trunk set --subport port=rac2-priv-port,segmentation-type=vlan,segmentation-id=4006 rac2-trunk

openstack server create rac2 \
  --image "OL8.8-cloud" \
  --flavor rac-flavor \
  --key-name rac-key \
  --nic port-id=rac2-parent-port \
  --wait
```

### 4.3 VIP/SCAN 的 allowed-address-pairs（原理同之前，落到public的subport上）
```bash
for PORT in rac1-public-port rac2-public-port; do
  openstack port set $PORT \
    --allowed-address ip-address=192.168.56.111 \
    --allowed-address ip-address=192.168.56.112 \
    --allowed-address ip-address=192.168.56.121 \
    --allowed-address ip-address=192.168.56.122 \
    --allowed-address ip-address=192.168.56.123
done
```

---

## 五、创建Cinder共享盘（与之前一致，不受网络方案影响）

```bash
openstack volume type create ceph-multiattach \
  --property multiattach="<is> True" \
  --property volume_backend_name=ceph

openstack volume create --type ceph-multiattach --size 5  rac-ocr1
openstack volume create --type ceph-multiattach --size 5  rac-ocr2
openstack volume create --type ceph-multiattach --size 30 rac-data1
openstack volume create --type ceph-multiattach --size 30 rac-reco1

for vol in rac-ocr1 rac-ocr2 rac-data1 rac-reco1; do
  openstack server add volume rac1 ${vol}
  openstack server add volume rac2 ${vol}
done
```

---

## 六、验证Trunk是否生效

```bash
openstack network trunk show rac1-trunk
openstack network trunk show rac2-trunk
openstack server show rac1 -c addresses     # 这里不会显示trunk子网IP，需登录VM里配置802.1Q后才可见
```

> Neutron层面trunk只是把打了VLAN tag的以太网帧透传到VM的这一个vNIC，VM内部**必须自己起802.1Q子接口**才能收发对应VLAN的流量——这部分在预处理脚本 `02-RAC预处理一键脚本.sh` 里自动完成（配置 `ens3.1` / `ens3.4006`）。

---

## 七、下一步

登录两台VM，执行 `02-RAC预处理一键脚本.sh`，脚本会：
1. 创建 `ens3.1`（public，配192.168.56.x/24）
2. 创建 `ens3.4006`（private，配10.10.10.x/24）
3. 完成其余RAC预处理项
