#!/bin/bash
###############################################################################
# Oracle Grid Infrastructure 19c + Database 19c 静默安装编排脚本
# （OpenStack单宿主机 + 单网卡Trunk VLAN1/4006 环境适配版）
#
# 前提：
#   1. 已在两节点执行完 02-RAC预处理一键脚本.sh：
#        - ens3.1(public)、ens3.4006(private)两个VLAN子接口已生效
#        - 共享盘udev别名 /dev/asm-* 已生效
#   2. 两节点SSH互信已配置好（grid用户、oracle用户均可互相免密登录）
#   3. 已将 Oracle 官方下载的 GI 和 DB 安装介质解压到 /u01/software/grid 和
#      /u01/software/db
#   4. 仅在【第一个节点 rac1】以 grid/oracle 对应用户执行
#
# 用法：
#   su - grid
#   ./03-GI-DB静默安装脚本.sh gi     # 先装GI
#   su - oracle
#   ./03-GI-DB静默安装脚本.sh db     # 再装DB软件（不建库，用dbca单独建）
###############################################################################
set -e

GRID_HOME="/u01/app/19.0.0/grid"
DB_HOME="/u01/app/oracle/product/19.0.0/dbhome_1"
SOFTWARE_DIR="/u01/software"

CLUSTER_NAME="rac-cluster"
NODE1="rac1"
NODE2="rac2"
NODE1_VIP="rac1-vip"
NODE2_VIP="rac2-vip"
SCAN_NAME="rac-scan"
SCAN_PORT="1521"

# 单网卡Trunk环境下，GI认的是VLAN子接口名，不是物理网卡名
NIC_PUBLIC="ens3.1"
NIC_PRIVATE="ens3.4006"
NET_PUBLIC_CIDR="192.168.56.0"
NET_PRIVATE_CIDR="10.10.10.0"

ASM_DISK_OCR="/dev/asm-ocr1,/dev/asm-ocr2"
ASM_DISK_DATA="/dev/asm-data1"

ACTION="$1"

install_gi() {
  echo ">>> 检查VLAN子接口是否就绪"
  for nic in ${NIC_PUBLIC} ${NIC_PRIVATE}; do
    if ! ip link show "${nic}" &>/dev/null; then
      echo "错误：网卡 ${nic} 不存在，请先确认 02-RAC预处理一键脚本.sh 中的VLAN配置已生效" >&2
      exit 1
    fi
  done

  echo ">>> 生成 GI 静默安装响应文件 gi.rsp"
  cat > /tmp/gi.rsp <<EOF
oracle.install.responseFileVersion=/oracle/install/rspfmt_crsinstall_response_schema_v19.0.0
oracle.install.option=CRS_CONFIG
ORACLE_BASE=/u01/app/grid
ORACLE_HOME=${GRID_HOME}
oracle.install.asm.OSDBA=asmdba
oracle.install.asm.OSOPER=asmoper
oracle.install.asm.OSASM=asmadmin

oracle.install.crs.config.scanType=LOCAL_SCAN
oracle.install.crs.config.gpnp.scanName=${SCAN_NAME}
oracle.install.crs.config.gpnp.scanPort=${SCAN_PORT}
oracle.install.crs.config.clusterName=${CLUSTER_NAME}
oracle.install.crs.config.gpnp.configureGNS=false

oracle.install.crs.config.clusterNodes=${NODE1}:${NODE1_VIP}:HUB,${NODE2}:${NODE2_VIP}:HUB
oracle.install.crs.config.networkInterfaceList=${NIC_PUBLIC}:${NET_PUBLIC_CIDR}:1,${NIC_PRIVATE}:${NET_PRIVATE_CIDR}:2

oracle.install.asm.configureGIMRDataDG=false
oracle.install.crs.configureRHPS=false
oracle.install.crs.config.storageOption=FLEX_ASM_STORAGE
oracle.install.asm.SYSASMPassword=Oracle_2024#
oracle.install.asm.diskGroup.name=OCRVOTE
oracle.install.asm.diskGroup.redundancy=EXTERNAL
oracle.install.asm.diskGroup.AUSize=4
oracle.install.asm.diskGroup.disks=${ASM_DISK_OCR}
oracle.install.asm.diskGroup.diskDiscoveryString=/dev/asm-*
oracle.install.asm.monitorPassword=Oracle_2024#

oracle.install.crs.config.ignoreDownNodes=false
oracle.install.config.managementOption=NONE
EOF

  echo ">>> 执行 runInstaller（GI）"
  ${SOFTWARE_DIR}/grid/gridSetup.sh -silent -waitforcompletion \
    -responseFile /tmp/gi.rsp -ignorePrereqFailure

  echo ">>> 请按提示以root身份分别在两个节点执行 root.sh / orainstRoot.sh"
  echo "    通常在: ${GRID_HOME}/root.sh"
  echo "    安装程序运行结束会给出具体两条root脚本路径，请严格按提示顺序在两节点分别执行"
}

install_db() {
  echo ">>> 生成 DB 软件静默安装响应文件 db.rsp（仅装软件，不建库）"
  cat > /tmp/db.rsp <<EOF
oracle.install.responseFileVersion=/oracle/install/rspfmt_dbinstall_response_schema_v19.0.0
oracle.install.option=INSTALL_DB_SWONLY
ORACLE_BASE=/u01/app/oracle
ORACLE_HOME=${DB_HOME}
oracle.install.db.InstallEdition=EE
oracle.install.db.OSDBA_GROUP=dba
oracle.install.db.OSOPER_GROUP=oper
oracle.install.db.OSBACKUPDBA_GROUP=backupdba
oracle.install.db.OSDGDBA_GROUP=dgdba
oracle.install.db.OSKMDBA_GROUP=kmdba
oracle.install.db.OSRACDBA_GROUP=racdba
oracle.install.db.CLUSTER_NODES=${NODE1},${NODE2}
oracle.install.db.isRACOneInstall=false
EOF

  echo ">>> 执行 runInstaller（DB软件）"
  ${SOFTWARE_DIR}/db/runInstaller -silent -waitforcompletion \
    -responseFile /tmp/db.rsp -ignorePrereqFailure

  echo ">>> 请按提示以root身份分别在两个节点执行 root.sh"
  echo ""
  echo ">>> DB软件装完后，用dbca静默建库示例（RAC库）："
  cat <<'DBCA'
    dbca -silent -createDatabase \
      -templateName General_Purpose.dbc \
      -gdbName racdb -sid racdb \
      -sysPassword Oracle_2024# -systemPassword Oracle_2024# \
      -createAsContainerDatabase false \
      -databaseType MULTIPURPOSE \
      -storageType ASM -diskGroupName DATA -recoveryGroupName RECO \
      -nodelist rac1,rac2 \
      -characterSet AL32UTF8 \
      -totalMemory 4096
DBCA
}

case "$ACTION" in
  gi) install_gi ;;
  db) install_db ;;
  *)
    echo "用法: $0 [gi|db]"
    exit 1
    ;;
esac
