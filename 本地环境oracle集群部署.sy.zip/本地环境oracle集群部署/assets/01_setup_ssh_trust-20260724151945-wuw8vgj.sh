#!/usr/bin/env bash
# 01_setup_ssh_trust.sh —— 在 racnode1 上执行一次即可
# 为 root / grid / oracle 三个账号在两节点间建立双向 SSH Key 互信
# 前置: export ROOT_PASSWD / GRID_PASSWD / ORACLE_PASSWD (与00脚本一致)
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

: "${ROOT_PASSWD:?}"; : "${GRID_PASSWD:?}"; : "${ORACLE_PASSWD:?}"

HOSTS=("$NODE1_HOST" "$NODE2_HOST" "${NODE1_HOST}-priv" "${NODE2_HOST}-priv")

setup_trust_for_user() {
  local user=$1 pass=$2
  echo "==> 配置 ${user} 用户互信"
  local home
  home=$(getent passwd "$user" | cut -d: -f6)
  su - "$user" -c "mkdir -p ~/.ssh && chmod 700 ~/.ssh"
  su - "$user" -c "test -f ~/.ssh/id_rsa || ssh-keygen -t rsa -N '' -f ~/.ssh/id_rsa"

  # 关闭 StrictHostKeyChecking，避免首次连接交互
  su - "$user" -c "cat > ~/.ssh/config <<EOF
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile=/dev/null
EOF
chmod 600 ~/.ssh/config"

  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    echo "  -> 分发公钥至 ${h}"
    sshpass -p "$pass" su - "$user" -c \
      "ssh-copy-id -o StrictHostKeyChecking=no ${user}@${h}" 2>&1 | grep -v "^Warning" || true
  done

  # 拉取对端 authorized_keys 合并，确保 node1<->node2 互相都能免密（而不仅是单向）
  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    su - "$user" -c "ssh -o StrictHostKeyChecking=no ${user}@${h} 'cat ~/.ssh/authorized_keys'" \
      >> "${home}/.ssh/authorized_keys.merged" || true
  done
  su - "$user" -c "sort -u ~/.ssh/authorized_keys.merged > ~/.ssh/authorized_keys; chmod 600 ~/.ssh/authorized_keys; rm -f ~/.ssh/authorized_keys.merged"
  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    sshpass -p "$pass" su - "$user" -c \
      "scp -o StrictHostKeyChecking=no ~/.ssh/authorized_keys ${user}@${h}:~/.ssh/authorized_keys"
  done
}

setup_trust_for_user root         "$ROOT_PASSWD"
setup_trust_for_user "$GRID_USER"   "$GRID_PASSWD"
setup_trust_for_user "$ORACLE_USER" "$ORACLE_PASSWD"

echo "==> 校验（应无密码提示直接返回hostname）"
for u in root "$GRID_USER" "$ORACLE_USER"; do
  for h in "$NODE1_HOST" "$NODE2_HOST"; do
    echo -n "  $u@$h: "
    su - "$u" -c "ssh -o BatchMode=yes ${h} hostname" || echo "FAILED"
  done
done

echo "SSH互信配置完成。"
echo "注: Grid Infrastructure 19.3 也可用官方工具二次校验/补配:"
echo "  \$GRID_STAGING/sshsetup/sshUserSetup.sh -user ${GRID_USER} -hosts \"${NODE1_HOST} ${NODE2_HOST}\" -advanced -exverify -confirm"
