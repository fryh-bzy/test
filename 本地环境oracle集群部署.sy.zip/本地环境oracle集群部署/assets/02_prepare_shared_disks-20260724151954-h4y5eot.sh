#!/usr/bin/env bash
# 02_prepare_shared_disks.sh —— 共享卷分区 + udev持久化命名 + grid:asmadmin授权
# 用法: 在 racnode1 上执行一次做规划+生成udev规则文件，
#      然后脚本自动通过root ssh互信把规则同步到 racnode2 并各自触发
#
# 前置: export SHARED_DISKS="/dev/vdb /dev/vdc /dev/vdd /dev/vde"
#       顺序需与 rac_env.conf 中 ASM_DISKS_OCR / ASM_DISKS_DATA 的命名一一对应
#       (第1块 -> OCR, 后3块 -> DATA)
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

: "${SHARED_DISKS:?请先 export SHARED_DISKS=\"/dev/vdb /dev/vdc /dev/vdd /dev/vde\"}"
DISKS=($SHARED_DISKS)
LABELS=($ASM_DISKS_OCR $ASM_DISKS_DATA)   # 顺序对应: asm-ocr01 asm-data01 asm-data02 asm-data03

[ "${#DISKS[@]}" -eq "${#LABELS[@]}" ] || { echo "盘数与标签数不一致"; exit 1; }

RULES_FILE=/etc/udev/rules.d/99-oracle-asmdisks.rules
: > /tmp/99-oracle-asmdisks.rules

echo "==> [1/4] 逐块盘分区 (parted, GPT单分区, 整盘留给ASM)"
for dev in "${DISKS[@]}"; do
  if ! parted -s "$dev" print 2>/dev/null | grep -q "Number"; then
    parted -s "$dev" mklabel gpt mkpart primary 0% 100%
  fi
  partprobe "$dev"
done
sleep 2

echo "==> [2/4] 采集每块分区的 ID_SERIAL，生成udev规则(按 rac_env.conf 命名映射)"
for i in "${!DISKS[@]}"; do
  part="${DISKS[$i]}1"
  [ -b "$part" ] || part="${DISKS[$i]}p1"
  serial=$(udevadm info --query=property --name="$part" | awk -F= '/^ID_SERIAL=/{print $2}')
  [ -n "$serial" ] || { echo "未取到 $part 的 ID_SERIAL，检查设备是否为virtio-scsi"; exit 1; }
  label=${LABELS[$i]}
  echo "  $part -> serial=$serial -> /dev/${label}"
  echo "KERNEL==\"sd*|vd*\", ENV{ID_SERIAL}==\"${serial}\", SYMLINK+=\"${label}\", OWNER=\"${GRID_USER}\", GROUP=\"asmadmin\", MODE=\"0660\"" \
    >> /tmp/99-oracle-asmdisks.rules
done

cp /tmp/99-oracle-asmdisks.rules "$RULES_FILE"
udevadm control --reload-rules
udevadm trigger --type=devices --action=change
sleep 2
echo "==> 本机(node1)结果:"; ls -l /dev/asm-* 2>/dev/null || echo "  未生成/dev/asm-*，请检查规则匹配"

echo "==> [3/4] 同步udev规则到 ${NODE2_HOST} 并触发 (依赖01脚本已建立root互信)"
scp -o StrictHostKeyChecking=no "$RULES_FILE" root@${NODE2_HOST}:"$RULES_FILE"
ssh -o StrictHostKeyChecking=no root@${NODE2_HOST} \
  "udevadm control --reload-rules && udevadm trigger --type=devices --action=change && sleep 2 && ls -l /dev/asm-* 2>/dev/null"

echo "==> [4/4] 完成。ASM发现字符串建议设置为: /dev/asm-*"
echo "    OCR盘  : /dev/${ASM_DISKS_OCR}"
echo "    DATA盘 : $(echo ${ASM_DISKS_DATA} | tr ' ' '\n' | sed 's#^#/dev/#' | tr '\n' ' ')"
