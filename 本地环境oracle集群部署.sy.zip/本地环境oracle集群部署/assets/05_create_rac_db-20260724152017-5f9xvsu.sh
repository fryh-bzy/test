#!/usr/bin/env bash
# 05_create_rac_db.sh —— 在 racnode1 上以 oracle 用户上下文执行(脚本以root起, 内部su)
# dbca静默建库: 双节点RAC, 存储用ASM +DATA
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

echo "==> [1/3] 建库前确认 +DATA 磁盘组已挂载(grid用户视角)"
su - ${GRID_USER} -c "${GRID_HOME}/bin/asmcmd lsdg" | grep -q "${ASM_DG_DATA}" \
  || { echo "+${ASM_DG_DATA} 磁盘组未就绪，请先完成02/03脚本"; exit 1; }

echo "==> [2/3] dbca -silent -createDatabase"
su - ${ORACLE_USER} -c "${DB_HOME}/bin/dbca -silent -createDatabase \
  -templateName General_Purpose.dbc \
  -gdbName ${DB_NAME} \
  -sid ${DB_NAME} \
  -createAsContainerDatabase false \
  -sysPassword '${SYS_PASSWORD}' \
  -systemPassword '${SYS_PASSWORD}' \
  -dbsnmpPassword '${SYS_PASSWORD}' \
  -characterSet ${CHARACTER_SET} \
  -databaseType MULTIPURPOSE \
  -storageType ASM \
  -diskGroupName ${ASM_DG_DATA} \
  -nodelist ${NODE1_HOST},${NODE2_HOST} \
  -recoveryAreaDestination ${ASM_DG_DATA} \
  -emConfiguration NONE \
  -automaticMemoryManagement false \
  -totalMemory 4096"

echo "==> [3/3] 建库后集群资源状态"
su - ${GRID_USER} -c "${GRID_HOME}/bin/srvctl status database -d ${DB_NAME}"
su - ${GRID_USER} -c "${GRID_HOME}/bin/crsctl stat res -t"

echo "RAC数据库 ${DB_NAME} 创建完成，双节点均已注册实例并可通过SCAN(${SCAN_NAME}.${DOMAIN}:${SCAN_PORT}/${DB_NAME})连接。"
