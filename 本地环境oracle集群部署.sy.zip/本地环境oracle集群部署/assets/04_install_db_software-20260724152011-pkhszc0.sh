#!/usr/bin/env bash
# 04_install_db_software.sh —— 在 racnode1 上以 root 执行
# 完成: 解压DB介质 -> oracle用户静默安装(仅软件,集群模式) -> 两节点root.sh
set -euo pipefail
BASEDIR=$(cd "$(dirname "$0")" && pwd)
source "$BASEDIR/rac_env.conf"

echo "==> [1/4] 解压 DB 介质到 ${DB_HOME} (oracle用户)"
su - ${ORACLE_USER} -c "unzip -oq ${DB_ZIP} -d ${DB_HOME}"

echo "==> [2/4] 渲染响应文件 db_install.rsp"
set -a; source "$BASEDIR/rac_env.conf"; set +a
envsubst < "$BASEDIR/db_install.rsp.template" > /tmp/db_install.rsp
chown ${ORACLE_USER}:oinstall /tmp/db_install.rsp
su - ${ORACLE_USER} -c "cp /tmp/db_install.rsp ${DB_HOME}/db_install.rsp"

echo "==> [3/4] runInstaller 静默安装（软件将自动推送到${NODE2_HOST}，依赖oracle用户互信）"
su - ${ORACLE_USER} -c "${DB_HOME}/runInstaller -silent -waitforcompletion \
    -responseFile ${DB_HOME}/db_install.rsp -ignorePrereq" || DB_RC=$?
echo "OUI阶段返回码: ${DB_RC:-0} (需要root.sh属正常)"

echo "==> [4/4] 两节点执行 root.sh"
for h in ${NODE1_HOST} ${NODE2_HOST}; do
  echo "  -> ${h}: root.sh"
  ssh -o StrictHostKeyChecking=no root@${h} "${DB_HOME}/root.sh"
done

echo "DB Home 软件（RAC集群模式）安装完成，下一步执行 05_create_rac_db.sh 建库。"
